import React, { useState, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ChevronLeft, ChevronRight, ArrowRight, Flame, Sparkles, ShieldCheck,
  ShoppingBag, Check, Plus
} from 'lucide-react'
import { useStore } from '../../context/StoreContext'

const HERO_SLIDES = [
  {
    id: 1,
    eyebrow: "ANCIENT PURITY. MODERN WELLNESS.",
    titleLine1: "Pure Earth.",
    titleLine2: "Extraordinary Taste.",
    subtitle: "Bambaura 9X Crystal Salt\nFrom ancient mineral-rich mountain reserves.",
    ctaText: "SHOP NOW",
    ctaLink: "/product",
    image: "/images/hero.png",
    mobileImage: "/images/hero.png",
    tagline: "100% Natural • 9X Mineral Rich • Lab Tested",
    align: "left"
  },
  {
    id: 2,
    eyebrow: "TRADITIONAL BAMBOO CRAFT. NINE FIRINGS.",
    titleLine1: "Hand-Roasted in",
    titleLine2: "Mountain Bamboo.",
    subtitle: "Prepared over 21 days inside bamboo stalks sealed with natural yellow clay over pine firewood.",
    ctaText: "EXPLORE THE PROCESS",
    ctaLink: "/process",
    image: "/images/sunrise.png",
    mobileImage: "/images/sunrise.png",
    tagline: "21-Day Roasting • 1,500°C Peak Fusion • Pure Yellow Clay",
    align: "left"
  },
  {
    id: 3,
    eyebrow: "LABORATORY TESTED. 100% PURE.",
    titleLine1: "Mineral Depth &",
    titleLine2: "Purity Redefined.",
    subtitle: "Naturally alkaline profile, zero synthetic anti-caking agents, and ISO/IEC 17025 accredited batch testing.",
    ctaText: "VIEW LAB RESULTS",
    ctaLink: "/science",
    image: "/images/redefined.png",
    mobileImage: "/images/redefined.png",
    tagline: "Lead <0.01 ppm • Zero Microplastics • pH 9.8+ Alkaline",
    align: "left"
  },
  {
    id: 4,
    eyebrow: "THE GOURMET FINISHING RITUAL.",
    titleLine1: "A Small Pinch",
    titleLine2: "is Enough.",
    subtitle: "Distinctive brownish granules that dissolve slowly with delicate smoky umami on eggs, meats, and fresh fruit.",
    ctaText: "VIEW 5 EASY USES",
    ctaLink: "/recipes",
    image: "/images/extracted/bambaura_packaging_showcase_duo.jpg",
    mobileImage: "/images/extracted/bambaura_packaging_showcase_duo.jpg",
    tagline: "Delicate Granules • Coarse Finishing Crystals • Dual Packaging",
    align: "left"
  }
]

export default function HeroSection({ onSelectGram }) {
  const { productData, formatPrice, addToCart, showToast } = useStore()
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const [touchStart, setTouchStart] = useState(null)
  const [touchEnd, setTouchEnd] = useState(null)

  const slideCount = HERO_SLIDES.length
  const activeSlide = HERO_SLIDES[currentSlide]

  // Autoplay timer (every 6 seconds)
  useEffect(() => {
    if (isPaused) return
    const timer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % slideCount)
    }, 6000)
    return () => clearInterval(timer)
  }, [isPaused, slideCount])

  // Touch Swipe Handlers for Mobile
  const handleTouchStart = (e) => {
    setTouchEnd(null)
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return
    const distance = touchStart - touchEnd
    if (distance > 50) {
      // Swiped Left
      nextSlide()
    } else if (distance < -50) {
      // Swiped Right
      prevSlide()
    }
  }

  const nextSlide = () => setCurrentSlide(prev => (prev + 1) % slideCount)
  const prevSlide = () => setCurrentSlide(prev => (prev - 1 + slideCount) % slideCount)

  const handleQuickAdd = () => {
    const variant100g = productData.gramVariants.find(v => v.grams === '100g') || productData.gramVariants[0]
    addToCart({
      id: 'bambaura-9x-salt',
      title: 'Bambaura 9X Bamboo Roasted Salt',
      grams: variant100g.grams,
      grind: 'Fine Granules',
      priceUSD: variant100g.priceUSD,
      image: variant100g.image,
      quantity: 1
    })
    showToast(`Added 100g Signature Canister (${formatPrice(variant100g.priceUSD)}) to your cart!`, 'success')
  }

  return (
    <section
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className="relative w-full overflow-hidden select-none bg-[#f5efe6] dark:bg-[#0c0303]"
      aria-label="Bambaura Hero Slider Banner"
    >
      {/* SLIDER VIEWPORT */}
      <div className="relative min-h-[580px] sm:min-h-[640px] lg:min-h-[720px] flex items-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeSlide.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.65, ease: "easeInOut" }}
            className="absolute inset-0 w-full h-full"
          >
            {/* BACKGROUND IMAGE WITH ART-DIRECTED CROP */}
            <div className="absolute inset-0 w-full h-full">
              <img
                src={activeSlide.image}
                alt={`${activeSlide.titleLine1} ${activeSlide.titleLine2}`}
                className="w-full h-full object-cover object-center lg:object-[center_right] filter brightness-[0.98]"
              />
              {/* SOFT NATURAL LIGHTING GRADIENT OVERLAY FOR READABILITY */}
              <div className="absolute inset-0 bg-gradient-to-r from-[#faf6f0]/95 via-[#faf6f0]/80 to-transparent lg:via-[#faf6f0]/50 dark:from-[#0c0303]/95 dark:via-[#0c0303]/75 dark:to-transparent" />
              {/* TOP / BOTTOM EDGE BLENDS */}
              <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#faf6f0] dark:from-[#120505] to-transparent pointer-events-none" />
            </div>

            {/* EDITORIAL CONTENT OVERLAY (MATCHES REFERENCE MOCKUP) */}
            <div className="relative max-w-7xl mx-auto px-6 sm:px-12 h-full flex items-center z-10 py-16 sm:py-24">
              <div className="max-w-xl lg:max-w-2xl space-y-5 text-left">
                
                {/* EYEBROW / BADGE */}
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1, duration: 0.4 }}
                  className="inline-block"
                >
                  <span className="text-xs font-mono uppercase tracking-[0.2em] font-semibold text-[#8c6027] dark:text-[#dfb983] block">
                    {activeSlide.eyebrow}
                  </span>
                </motion.div>

                {/* MAIN HEADLINE IN PLAYFAIR SERIF */}
                <motion.h1
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                  className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-[#381014] dark:text-[#fdfbf7] leading-[1.1] tracking-tight"
                >
                  {activeSlide.titleLine1} <br />
                  <span className="italic font-normal">{activeSlide.titleLine2}</span>
                </motion.h1>

                {/* SUBTITLE */}
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                  className="text-sm sm:text-base text-[#4a2e2b] dark:text-[#d9c7be] leading-relaxed whitespace-pre-line max-w-lg font-sans"
                >
                  {activeSlide.subtitle}
                </motion.p>

                {/* CALL TO ACTION BUTTON (EXACT DEEP BURGUNDY STYLE FROM MOCKUP) */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4, duration: 0.5 }}
                  className="pt-2 flex flex-wrap items-center gap-4"
                >
                  <Link
                    to={activeSlide.ctaLink}
                    className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg bg-[#401010] hover:bg-[#2c0909] dark:bg-[#dfb983] dark:hover:bg-[#eed2a9] text-[#faf5ee] dark:text-[#180505] font-semibold text-xs tracking-wider uppercase transition-all shadow-md group cursor-pointer active:scale-95"
                  >
                    <span>{activeSlide.ctaText}</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>

                  <button
                    type="button"
                    onClick={handleQuickAdd}
                    className="inline-flex items-center gap-2 px-5 py-3.5 rounded-lg border border-[#381014]/40 hover:border-[#381014] dark:border-[#dfb983]/60 dark:hover:border-[#dfb983] text-[#381014] dark:text-[#dfb983] font-semibold text-xs tracking-wider uppercase transition-all bg-white/60 dark:bg-[#1a0808]/60 hover:bg-white dark:hover:bg-[#1a0808] cursor-pointer shadow-xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Quick Add (100g)</span>
                  </button>
                </motion.div>

                {/* PROOF TAGLINE */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5, duration: 0.4 }}
                  className="pt-2 text-xs font-mono text-[#8c6027] dark:text-[#dfb983] flex items-center gap-2"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#b28346] shrink-0" />
                  <span>{activeSlide.tagline}</span>
                </motion.div>

              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* LEFT & RIGHT NAVIGATION CHEVRONS */}
        <button
          type="button"
          onClick={prevSlide}
          className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-white/70 hover:bg-white dark:bg-[#180707]/70 dark:hover:bg-[#180707] text-[#381014] dark:text-[#dfb983] border border-[#e8decb] dark:border-[#381616] flex items-center justify-center transition-all shadow-md hover:scale-105 active:scale-95 cursor-pointer backdrop-blur-xs"
          aria-label="Previous Slide"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          type="button"
          onClick={nextSlide}
          className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-white/70 hover:bg-white dark:bg-[#180707]/70 dark:hover:bg-[#180707] text-[#381014] dark:text-[#dfb983] border border-[#e8decb] dark:border-[#381616] flex items-center justify-center transition-all shadow-md hover:scale-105 active:scale-95 cursor-pointer backdrop-blur-xs"
          aria-label="Next Slide"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* SLIDE DOT PAGINATION INDICATORS */}
        <div className="absolute bottom-6 inset-x-0 z-20 flex items-center justify-center gap-2.5">
          {HERO_SLIDES.map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setCurrentSlide(idx)}
              className={`h-2 transition-all rounded-full cursor-pointer ${
                currentSlide === idx
                  ? 'w-8 bg-[#401010] dark:bg-[#dfb983]'
                  : 'w-2 bg-[#381014]/30 dark:bg-white/30 hover:bg-[#381014]/60'
              }`}
              aria-label={`Go to Slide ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
