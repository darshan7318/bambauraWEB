import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Flame, ShieldCheck, ArrowRight, Star, Sparkles, Check, ChevronRight,
  Award, Clock, Heart, Truck, Eye, ChefHat, Activity, ShoppingBag,
  HelpCircle, ChevronDown, CheckCircle2, Droplet, Gift
} from 'lucide-react'
import { useStore } from '../context/StoreContext'

// Art-directed UI Components
import AnimatedPillTabs from '../components/ui/AnimatedPillTabs'
import HeroSection from '../components/hero/HeroSection'
import BenefitsSection from '../components/BenefitsSection'
import SaltComparison from '../components/SaltComparison'
import HOME_DATA from '../data/homeData.json'
import FAQS_DATA from '../data/faqs.json'
import RECIPES_DATA from '../data/recipes.json'

const iconMap = {
  Flame,
  Sparkles,
  ShieldCheck,
  Check,
  Award,
  ChefHat
}

export default function Home() {
  const { productData, formatPrice, countryConfig, addToCart } = useStore()
  const [selectedGramId, setSelectedGramId] = useState('100g')
  const [activeFaqIndex, setActiveFaqIndex] = useState(0)
  const [activeUseIndex, setActiveUseIndex] = useState(0)

  const selectedGram =
    productData.gramVariants.find(v => v.grams === selectedGramId) ||
    productData.gramVariants[0] ||
    productData.gramVariants[1]

  const gramTabs = productData.gramVariants.map(v => ({
    id: v.grams,
    label: v.label,
    badge: v.popular ? 'Popular' : null
  }))

  const handleQuickAdd = () => {
    addToCart({
      id: 'bambaura-9x-salt',
      title: 'Bambaura 9X Bamboo Roasted Salt',
      grams: selectedGram.grams,
      grind: 'Fine Granules',
      priceUSD: selectedGram.priceUSD,
      image: selectedGram.image,
      quantity: 1
    })
  }

  return (
    <div className="space-y-16 sm:space-y-24 pb-24 overflow-hidden">
      
      {/* 1. HERO SLIDER BANNER WITH MOUNTAIN STAGING & 9-CYCLE STORY */}
      <HeroSection
        onSelectGram={(g) => setSelectedGramId(g)}
      />

      {/* 2. 6-BADGE ART-DIRECTED FEATURE STRIP (MATCHING MOCKUP) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 -mt-8 relative z-20">
        <div className="py-4 px-6 rounded-2xl bg-[#faf6f0] dark:bg-[#1a0808] border border-[#e8decb] dark:border-[#381616] shadow-sm">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 text-center items-center divide-y sm:divide-y-0 sm:divide-x divide-[#e8decb] dark:divide-[#381616]">
            <div className="flex items-center justify-center gap-2 py-1 px-2 text-[#401010] dark:text-[#dfb983]">
              <Sparkles className="w-4 h-4 text-[#b28346] shrink-0" />
              <span className="font-serif font-bold tracking-tight text-xs">100% Natural</span>
            </div>
            <div className="flex items-center justify-center gap-2 py-1 px-2 text-[#401010] dark:text-[#dfb983]">
              <Flame className="w-4 h-4 text-[#b28346] shrink-0" />
              <span className="font-serif font-bold tracking-tight text-xs">9X Mineral Rich</span>
            </div>
            <div className="flex items-center justify-center gap-2 py-1 px-2 text-[#401010] dark:text-[#dfb983]">
              <ShieldCheck className="w-4 h-4 text-[#b28346] shrink-0" />
              <span className="font-serif font-bold tracking-tight text-xs">Lab Tested</span>
            </div>
            <div className="flex items-center justify-center gap-2 py-1 px-2 text-[#401010] dark:text-[#dfb983]">
              <CheckCircle2 className="w-4 h-4 text-[#b28346] shrink-0" />
              <span className="font-serif font-bold tracking-tight text-xs">No Additives</span>
            </div>
            <div className="flex items-center justify-center gap-2 py-1 px-2 text-[#401010] dark:text-[#dfb983]">
              <Heart className="w-4 h-4 text-[#b28346] shrink-0" />
              <span className="font-serif font-bold tracking-tight text-xs">Ethically Sourced</span>
            </div>
            <div className="flex items-center justify-center gap-2 py-1 px-2 text-[#401010] dark:text-[#dfb983]">
              <Gift className="w-4 h-4 text-[#b28346] shrink-0" />
              <span className="font-serif font-bold tracking-tight text-xs">Perfect for Gifting</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. DISCOVER OUR RANGE SECTION (3 PRODUCT CARDS) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#8c6027] dark:text-[#dfb983]">
            Our Artisanal Collection
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#401010] dark:text-[#f7ebd9]">
            Discover Our Range
          </h2>
          <p className="text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
            Handcrafted mineral salts, perfected through ancient fire and Korean mountain bamboo traditions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* CARD 1: 9X BAMBOO ROASTED SALT */}
          <div className="group rounded-3xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] p-6 flex flex-col justify-between hover:shadow-xl hover:border-[#b28346]/50 transition-all duration-300">
            <div>
              <div className="aspect-square w-full rounded-2xl bg-[#faf5ee] dark:bg-[#200c0c] p-6 flex items-center justify-center overflow-hidden mb-6 relative">
                <span className="absolute top-3 left-3 text-xs font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-[#401010] text-[#f7ebd9]">
                  SIGNATURE 9X
                </span>
                <img
                  src="/images/extracted/bambaura_canister_front_100g.jpg"
                  alt="Bambaura 9X Bamboo Roasted Salt Canister"
                  className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500 filter drop-shadow-md"
                />
              </div>

              <div className="flex items-baseline justify-between mb-2">
                <h3 className="font-serif text-xl font-bold text-[#401010] dark:text-[#f7ebd9]">
                  9X Bamboo Roasted Salt
                </h3>
                <span className="font-serif text-lg font-bold text-[#401010] dark:text-[#dfb983]">
                  {formatPrice(24)}
                </span>
              </div>

              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] leading-relaxed mb-6">
                Roasted nine times in mountain bamboo tubes. Rich umami salinity with natural ocean &amp; bamboo trace minerals.
              </p>
            </div>

            <Link
              to="/product?grams=100g"
              className="w-full py-3.5 px-4 rounded-xl bg-[#401010] hover:bg-[#280808] dark:bg-[#dfb983] dark:hover:bg-[#eed2a9] text-[#f7ebd9] dark:text-[#140707] font-semibold text-xs uppercase tracking-wider text-center transition-colors flex items-center justify-center gap-2 group-hover:gap-3"
            >
              <span>SHOP 9X SALT</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* CARD 2: PURITY WHITE SALT */}
          <div className="group rounded-3xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] p-6 flex flex-col justify-between hover:shadow-xl hover:border-[#b28346]/50 transition-all duration-300">
            <div>
              <div className="aspect-square w-full rounded-2xl bg-[#faf5ee] dark:bg-[#200c0c] p-6 flex items-center justify-center overflow-hidden mb-6 relative">
                <span className="absolute top-3 left-3 text-xs font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-[#8c6027] text-[#f7ebd9]">
                  SUN-DRIED SEA SALT
                </span>
                <img
                  src="/images/extracted/purity_white_salt.jpg"
                  alt="Bambaura Purity White Salt with Ceramic Bowl"
                  className="w-full h-full object-cover rounded-xl group-hover:scale-105 transition-transform duration-500"
                />
              </div>

              <div className="flex items-baseline justify-between mb-2">
                <h3 className="font-serif text-xl font-bold text-[#401010] dark:text-[#f7ebd9]">
                  Purity White Salt
                </h3>
                <span className="font-serif text-lg font-bold text-[#401010] dark:text-[#dfb983]">
                  {formatPrice(18)}
                </span>
              </div>

              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] leading-relaxed mb-6">
                Sun-dried sea salt filtered through natural bamboo charcoal. Crisp, clean mineral finish for everyday fine dining.
              </p>
            </div>

            <Link
              to="/product?grams=100g"
              className="w-full py-3.5 px-4 rounded-xl bg-[#401010] hover:bg-[#280808] dark:bg-[#dfb983] dark:hover:bg-[#eed2a9] text-[#f7ebd9] dark:text-[#140707] font-semibold text-xs uppercase tracking-wider text-center transition-colors flex items-center justify-center gap-2 group-hover:gap-3"
            >
              <span>SHOP WHITE</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* CARD 3: NATURAL GREY SALT */}
          <div className="group rounded-3xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] p-6 flex flex-col justify-between hover:shadow-xl hover:border-[#b28346]/50 transition-all duration-300">
            <div>
              <div className="aspect-square w-full rounded-2xl bg-[#faf5ee] dark:bg-[#200c0c] p-6 flex items-center justify-center overflow-hidden mb-6 relative">
                <span className="absolute top-3 left-3 text-xs font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-[#52443d] text-[#f7ebd9]">
                  UNREFINED COASTAL
                </span>
                <img
                  src="/images/extracted/natural_grey_salt.jpg"
                  alt="Bambaura Natural Grey Salt with Slate Texture"
                  className="w-full h-full object-cover rounded-xl group-hover:scale-105 transition-transform duration-500"
                />
              </div>

              <div className="flex items-baseline justify-between mb-2">
                <h3 className="font-serif text-xl font-bold text-[#401010] dark:text-[#f7ebd9]">
                  Natural Grey Salt
                </h3>
                <span className="font-serif text-lg font-bold text-[#401010] dark:text-[#dfb983]">
                  {formatPrice(20)}
                </span>
              </div>

              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] leading-relaxed mb-6">
                Hand-harvested from coastal clay flats. Retains subtle natural moisture and ocean trace magnesium minerals.
              </p>
            </div>

            <Link
              to="/product?grams=100g"
              className="w-full py-3.5 px-4 rounded-xl bg-[#401010] hover:bg-[#280808] dark:bg-[#dfb983] dark:hover:bg-[#eed2a9] text-[#f7ebd9] dark:text-[#140707] font-semibold text-xs uppercase tracking-wider text-center transition-colors flex items-center justify-center gap-2 group-hover:gap-3"
            >
              <span>SHOP GREY</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 4. 4-TILE EDITORIAL STORIES GRID (MATCHING MOCKUP) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* TILE 1: WHY 9X */}
          <Link
            to="/why-9x"
            className="group relative rounded-3xl overflow-hidden min-h-[320px] flex flex-col justify-end p-6 border border-[#e8decb] dark:border-[#381616] shadow-md hover:shadow-xl transition-all"
          >
            <img
              src="/images/extracted/bambaura_real_crystals_1.jpg"
              alt="Macro view of 9X bamboo roasted salt crystals"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-75 group-hover:brightness-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
            <div className="relative z-10 space-y-2">
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#dfb983]">
                ANCIENT ALCHEMY
              </span>
              <h3 className="font-serif text-2xl font-bold text-white">
                Why 9X?
              </h3>
              <p className="text-xs text-stone-300 leading-relaxed line-clamp-2">
                Nine firings transform raw salt into an alkaline, mineral-rich culinary powerhouse.
              </p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-bold text-[#dfb983] group-hover:translate-x-1 transition-transform">
                <span>EXPLORE</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </Link>

          {/* TILE 2: HOW TO USE */}
          <Link
            to="/recipes"
            className="group relative rounded-3xl overflow-hidden min-h-[320px] flex flex-col justify-end p-6 border border-[#e8decb] dark:border-[#381616] shadow-md hover:shadow-xl transition-all"
          >
            <img
              src="/images/extracted/recipe_chicken.png"
              alt="Culinary roasted chicken seasoned with bamboo salt"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-75 group-hover:brightness-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
            <div className="relative z-10 space-y-2">
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#dfb983]">
                CULINARY CRAFT
              </span>
              <h3 className="font-serif text-2xl font-bold text-white">
                How to Use
              </h3>
              <p className="text-xs text-stone-300 leading-relaxed line-clamp-2">
                From morning eggs to seared meats and dark chocolate, discover culinary finishing techniques.
              </p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-bold text-[#dfb983] group-hover:translate-x-1 transition-transform">
                <span>GET INSPIRED</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </Link>

          {/* TILE 3: OUR STORY */}
          <Link
            to="/about"
            className="group relative rounded-3xl overflow-hidden min-h-[320px] flex flex-col justify-end p-6 border border-[#e8decb] dark:border-[#381616] shadow-md hover:shadow-xl transition-all"
          >
            <img
              src="/images/extracted/himalaya_mountains.png"
              alt="Pristine mountain peaks where bamboo is harvested"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-75 group-hover:brightness-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
            <div className="relative z-10 space-y-2">
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#dfb983]">
                TEMPLE HERITAGE
              </span>
              <h3 className="font-serif text-2xl font-bold text-white">
                Our Story
              </h3>
              <p className="text-xs text-stone-300 leading-relaxed line-clamp-2">
                Rooted in thousand-year-old Buddhist temple roasting traditions, handcrafted over pine wood embers.
              </p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-bold text-[#dfb983] group-hover:translate-x-1 transition-transform">
                <span>OUR STORY</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </Link>

          {/* TILE 4: LAB RESULTS */}
          <Link
            to="/science"
            className="group relative rounded-3xl overflow-hidden min-h-[320px] flex flex-col justify-end p-6 border border-[#e8decb] dark:border-[#381616] shadow-md hover:shadow-xl transition-all"
          >
            <img
              src="/images/extracted/lab_glassware_testing.jpg"
              alt="Laboratory glassware testing Bambaura mineral purity"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-75 group-hover:brightness-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
            <div className="relative z-10 space-y-2">
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#dfb983]">
                INDEPENDENT QUALITY
              </span>
              <h3 className="font-serif text-2xl font-bold text-white">
                Lab Results
              </h3>
              <p className="text-xs text-stone-300 leading-relaxed line-clamp-2">
                Heavy-metal screened, microplastic-free certified, and verified alkaline mineral composition.
              </p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-bold text-[#dfb983] group-hover:translate-x-1 transition-transform">
                <span>VIEW REPORTS</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </Link>
        </div>
      </section>

      {/* 5. BAMBAURA 9X TRADITIONAL BENEFITS */}
      <BenefitsSection />

      {/* 5. THE SINGLE PRODUCT HIGHLIGHT (100g, 250g, 50g, 500g ALLOCATIONS) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-3">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#8c6027] dark:text-[#dfb983]">
            Our Single Flagship Product
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#401010] dark:text-[#f7ebd9]">
            Bambaura 9X Bamboo Roasted Salt
          </h2>
          <p className="text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
            Prepared through nine roasting cycles inside bamboo tubes. Recognisable by its distinctive brownish colour and fine granules, this salt brings a unique story and presentation to your kitchen.
          </p>
        </div>

        {/* ANIMATED PILL TABS FOR GRAM SWITCHER */}
        <div className="flex justify-center mb-10">
          <AnimatedPillTabs
            tabs={gramTabs}
            activeTab={selectedGramId}
            onChange={(id) => setSelectedGramId(id)}
            layoutId="homeGramPill"
          />
        </div>

        {/* ACTIVE GRAM HIGHLIGHT CONTAINER */}
        <div className="rounded-3xl border border-[#e6d8c4] dark:border-[#381616] bg-white dark:bg-[#180707] shadow-lg overflow-hidden">
          <div className="p-8 sm:p-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-5 flex justify-center">
              <div className="w-64 h-64 sm:w-80 sm:h-80 p-6 flex items-center justify-center rounded-2xl bg-[#faf5ee]/60 dark:bg-[#200c0c]/60 border border-[#e6d8c4]/60 dark:border-[#381616]">
                <img
                  src={selectedGram.image}
                  alt={selectedGram.name}
                  className="w-full h-full object-contain filter drop-shadow-xl"
                />
              </div>
            </div>

            <div className="lg:col-span-7 space-y-5">
              <div>
                <span className="text-xs uppercase font-bold tracking-widest text-[#8c6027] dark:text-[#dfb983]">
                  Selected Allocation
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#401010] dark:text-[#f7ebd9] mt-1">
                  {selectedGram.name}
                </h3>
                <p className="text-sm text-[#6b534b] dark:text-[#c2ada4] mt-2">
                  {selectedGram.subtext}
                </p>
              </div>

              <div className="flex items-baseline gap-4">
                <span className="font-serif text-3xl sm:text-4xl font-bold text-[#401010] dark:text-[#dfb983]">
                  {formatPrice(selectedGram.priceUSD)}
                </span>
                <span className="text-xs text-[#9c8378] line-through">
                  Amazon MRP {formatPrice(selectedGram.amazonUSD)}
                </span>
                <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-3 py-1 rounded-full">
                  Direct Reserve Savings
                </span>
              </div>

              {/* USP LIST (MATCHING USER DIRECTIVE) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                <div className="flex items-center gap-2 text-[#401010] dark:text-[#f7ebd9]">
                  <Check className="w-4 h-4 text-[#b28346] shrink-0" />
                  <span>Nine Roasting Cycles in Bamboo Tubes</span>
                </div>
                <div className="flex items-center gap-2 text-[#401010] dark:text-[#f7ebd9]">
                  <Check className="w-4 h-4 text-[#b28346] shrink-0" />
                  <span>Distinctive Natural Brownish Colour</span>
                </div>
                <div className="flex items-center gap-2 text-[#401010] dark:text-[#f7ebd9]">
                  <Check className="w-4 h-4 text-[#b28346] shrink-0" />
                  <span>Fine Granule Texture for Cooking</span>
                </div>
                <div className="flex items-center gap-2 text-[#401010] dark:text-[#f7ebd9]">
                  <Check className="w-4 h-4 text-[#b28346] shrink-0" />
                  <span>Free Shipping over {countryConfig.symbol}{countryConfig.freeShip}</span>
                </div>
              </div>

              {/* CALL TO ACTION BUTTONS WITH INSTANT 1-CLICK ADD TO BAG */}
              <div className="pt-4 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={handleQuickAdd}
                  className="py-4 px-6 rounded-2xl bg-[#401010] hover:bg-[#280808] dark:bg-[#dfb983] dark:hover:bg-[#eed2a9] text-[#f7ebd9] dark:text-[#140707] font-semibold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg group"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to cart — {formatPrice(selectedGram.priceUSD)}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <Link
                  to={`/product?grams=${selectedGram.grams}`}
                  className="px-6 py-4 rounded-2xl border border-[#e6d8c4] dark:border-[#381616] text-[#401010] dark:text-[#f7ebd9] text-xs font-semibold hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                >
                  View Details &amp; Packaging
                </Link>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 5. THE 9-STAGE ALCHEMY STORY SECTION & 4 USP CARDS */}
      <section className="bg-[#401010] dark:bg-[#120404] text-[#f7ebd9] py-20 border-y border-[#b28346]/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-6 space-y-6">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#dfb983]">
                {HOME_DATA.alchemySection?.badge || 'The Roasting Journey'}
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold leading-tight">
                {HOME_DATA.alchemySection?.title || 'The Story of Nine Roasting Cycles Inside Bamboo Tubes'}
              </h2>
              {(HOME_DATA.alchemySection?.paragraphs || []).map((para, idx) => (
                <p key={idx} className="text-sm text-[#dfb983]/90 leading-relaxed">
                  {para}
                </p>
              ))}

              <div className="pt-2">
                <Link
                  to="/process"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-[#dfb983] text-[#120404] hover:bg-[#eed2a9] font-bold text-xs uppercase tracking-wider transition-colors shadow-sm"
                >
                  <span>Read The Complete 9-Cycle Journey</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Link>
              </div>
            </div>

            <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {HOME_DATA.uspCards.map((card, idx) => {
                const Icon = iconMap[card.icon] || Sparkles
                return (
                  <div key={idx} className="p-6 rounded-2xl bg-white/5 border border-[#b28346]/20 space-y-2 hover:border-[#dfb983]/40 transition-colors">
                    <Icon className="w-6 h-6 text-[#dfb983]" />
                    <h4 className="font-serif font-bold text-lg text-white">{card.title}</h4>
                    <p className="text-xs text-amber-100/70 leading-relaxed">{card.description}</p>
                  </div>
                )
              })}
            </div>

          </div>
        </div>
      </section>

      {/* 5. DETAILED COMPARISON MATRIX (BAMBAURA 9X VS OTHER SALTS) */}
      <SaltComparison />

      {/* 6. REAL ROASTED SALT PRESENTATION (FROM USER PHOTOS) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center p-8 sm:p-12 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] shadow-lg">
          <div className="lg:col-span-5 space-y-4">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#8c6027] dark:text-[#dfb983]">
              Authentic Visual Inspection
            </span>
            <h3 className="font-serif text-3xl font-bold text-[#401010] dark:text-[#f7ebd9]">
              Recognisable by its Distinctive Brownish Colour
            </h3>
            <p className="text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
              When natural rock salt is repeatedly roasted inside thick mountain bamboo stalks over pine firewood, the interaction of extreme heat, bamboo sap, and mineral clay produces this characteristic brownish-amber crystalline structure.
            </p>
            <div className="pt-2">
              <Link
                to="/product"
                className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#401010] dark:text-[#dfb983] hover:underline"
              >
                <span>View Packaging Options (100g & 250g)</span>
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="overflow-hidden rounded-2xl border border-[#b28346]/30 shadow-md group">
              <img
                src="/images/extracted/bambaura_packaging_showcase_duo.jpg"
                alt="Bambaura 9X 100g & 250g Packaging with Gold Barrier Pouch"
                className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="p-3 bg-[#faf5ee] dark:bg-[#200c0c] text-xs font-mono text-[#401010] dark:text-[#dfb983] flex items-center justify-between">
                <span>100g &amp; 250g Canisters + Pouch</span>
                <span className="font-bold">Pure Salt | Richer Living</span>
              </div>
            </div>

            <div className="overflow-hidden rounded-2xl border border-[#b28346]/30 shadow-md group">
              <img
                src="/images/extracted/bambaura_artisans_bamboo_kiln.jpg"
                alt="Traditional Mountain Bamboo Tube Roasting Over Fire"
                className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="p-3 bg-[#faf5ee] dark:bg-[#200c0c] text-xs font-mono text-[#401010] dark:text-[#dfb983] flex items-center justify-between">
                <span>Hand-Fired in Bamboo Tubes</span>
                <span className="font-bold">Nine Cycles</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. INTERACTIVE 5-DISH CULINARY PAIRING STAGE (BRIEF ITEM 4) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="p-8 sm:p-12 space-y-8 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] shadow-lg">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-[#e6d8c4] dark:border-[#381616] pb-6">
            <div className="space-y-2 max-w-2xl">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#8c6027] dark:text-[#dfb983]">
                Taste Profile &amp; Five Everyday Uses
              </span>
              <h3 className="font-serif text-3xl sm:text-4xl font-bold text-[#401010] dark:text-[#f7ebd9]">
                Smoky, savoury and mineral-rich, with a gentle egg-like note.
              </h3>
              <p className="text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
                A single pinch is enough. Use Bambaura 9X as an elevated finishing salt at the table, not for bulk cooking.
              </p>
            </div>

            <Link
              to="/recipes"
              className="text-xs font-bold uppercase tracking-wider text-[#8c6027] dark:text-[#dfb983] hover:underline flex items-center gap-1.5 shrink-0"
            >
              <span>Explore All 5 Recipes</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* 5 DISH BUTTON SELECTORS */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            {(RECIPES_DATA.fiveUses || []).map((use, idx) => (
              <button
                key={use.id}
                type="button"
                onClick={() => setActiveUseIndex(idx)}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  activeUseIndex === idx
                    ? 'border-[#b28346] bg-[#401010] text-[#f7ebd9] dark:bg-[#dfb983] dark:text-[#120505] shadow-md font-bold scale-[1.02]'
                    : 'border-[#e6d8c4] dark:border-[#381616] bg-[#faf5ee] dark:bg-[#1a0808] text-[#401010] dark:text-[#f7ebd9] hover:border-[#b28346]/60'
                }`}
              >
                <span className="text-xs font-mono uppercase block opacity-80">
                  0{idx + 1} • {use.category}
                </span>
                <span className="font-serif font-bold text-xs sm:text-sm mt-1 block line-clamp-1">
                  {use.title}
                </span>
              </button>
            ))}
          </div>

          {/* ACTIVE DISH VISUAL STAGE */}
          {RECIPES_DATA.fiveUses && RECIPES_DATA.fiveUses[activeUseIndex] && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center pt-2">
              <div className="lg:col-span-7 space-y-4">
                <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#8c6027] dark:text-[#dfb983]">
                  Recommended Pairing No. 0{activeUseIndex + 1}
                </span>
                <h4 className="font-serif text-2xl sm:text-3xl font-bold text-[#401010] dark:text-[#f7ebd9]">
                  {RECIPES_DATA.fiveUses[activeUseIndex].title}
                </h4>
                <p className="text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
                  {RECIPES_DATA.fiveUses[activeUseIndex].description}
                </p>

                <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-[#8c6027] dark:text-[#dfb983] pt-1">
                  <span className="px-3 py-1 rounded-full bg-[#faf5ee] dark:bg-[#200c0c] border border-[#e6d8c4] dark:border-[#381616]">
                    Ideal Texture: <strong>{RECIPES_DATA.fiveUses[activeUseIndex].grind}</strong>
                  </span>
                  <span className="px-3 py-1 rounded-full bg-[#faf5ee] dark:bg-[#200c0c] border border-[#e6d8c4] dark:border-[#381616]">
                    Serving Size: <strong>1 Gentle Pinch</strong>
                  </span>
                </div>

                <div className="pt-2">
                  <Link
                    to="/product"
                    className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-[#401010] hover:bg-[#280808] dark:bg-[#dfb983] dark:hover:bg-[#eed2a9] text-[#f7ebd9] dark:text-[#120505] font-semibold text-xs uppercase tracking-wider transition-colors shadow-sm"
                  >
                    <span>Order Finishing Canister — {formatPrice(24)}</span>
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Link>
                </div>
              </div>

              <div className="lg:col-span-5 overflow-hidden rounded-2xl border border-[#b28346]/40 shadow-xl max-h-72">
                <AnimatePresence mode="wait">
                  <motion.img
                    key={RECIPES_DATA.fiveUses[activeUseIndex].image}
                    src={RECIPES_DATA.fiveUses[activeUseIndex].image}
                    alt={RECIPES_DATA.fiveUses[activeUseIndex].title}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.25 }}
                    className="w-full h-72 object-cover"
                  />
                </AnimatePresence>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* 8. CULINARY PERSPECTIVES & SENSORY TASTING NOTES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-10 space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#faf5ee] dark:bg-[#200c0c] border border-[#b28346]/40 text-[#8c6027] dark:text-[#dfb983] text-xs font-mono font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Pre-Launch Benchmark Profiling</span>
          </div>
          <h2 className="font-serif text-3xl font-bold text-[#401010] dark:text-[#f7ebd9]">
            Culinary Perspectives &amp; Tasting Notes
          </h2>
          <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] max-w-md mx-auto">
            Sensory evaluation and finishing notes from our initial culinary testing sessions:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] space-y-3 shadow-xs hover:border-[#8c6027]/40 transition-colors">
            <span className="text-xs font-mono uppercase tracking-wider text-[#8c6027] dark:text-[#dfb983] font-bold">
              Profile 01 • Morning Eggs
            </span>
            <h4 className="font-serif font-bold text-base text-[#401010] dark:text-[#f7ebd9]">
              "Delicate smoky warmth on soft-boiled eggs"
            </h4>
            <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
              The brownish granules dissolve slowly, releasing a gentle egg-like umami fragrance that elevates poached eggs, avocados, and buttered toast without synthetic seasonings.
            </p>
            <div className="pt-2 border-t border-[#e6d8c4]/60 dark:border-[#381616] text-xs flex justify-between items-center text-[#8c6027] dark:text-[#dfb983]">
              <span className="font-semibold">Culinary Testing Note</span>
              <span className="font-mono text-xs">Fine Granules</span>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] space-y-3 shadow-xs hover:border-[#8c6027]/40 transition-colors">
            <span className="text-xs font-mono uppercase tracking-wider text-[#8c6027] dark:text-[#dfb983] font-bold">
              Profile 02 • High-Heat Sear
            </span>
            <h4 className="font-serif font-bold text-base text-[#401010] dark:text-[#f7ebd9]">
              "Deep savoury finish on grilled paneer &amp; meats"
            </h4>
            <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
              Distinctive from raw sea salt or pink rock salt. The roasted bamboo character balances caramelized meat crusts and sizzling paneer tikka with rounded, velvety salinity.
            </p>
            <div className="pt-2 border-t border-[#e6d8c4]/60 dark:border-[#381616] text-xs flex justify-between items-center text-[#8c6027] dark:text-[#dfb983]">
              <span className="font-semibold">Culinary Testing Note</span>
              <span className="font-mono text-xs">Finishing Crystals</span>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] space-y-3 shadow-xs hover:border-[#8c6027]/40 transition-colors">
            <span className="text-xs font-mono uppercase tracking-wider text-[#8c6027] dark:text-[#dfb983] font-bold">
              Profile 03 • Contrast Finishing
            </span>
            <h4 className="font-serif font-bold text-base text-[#401010] dark:text-[#f7ebd9]">
              "Unexpected contrast on chilled fruit &amp; chocolate"
            </h4>
            <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
              A gentle pinch over cold watermelon slices, ripe mango, or dark chocolate fudge creates a striking sweet-and-smoky contrast that highlights natural flavours.
            </p>
            <div className="pt-2 border-t border-[#e6d8c4]/60 dark:border-[#381616] text-xs flex justify-between items-center text-[#8c6027] dark:text-[#dfb983]">
              <span className="font-semibold">Culinary Testing Note</span>
              <span className="font-mono text-xs">Fine &amp; Crystals</span>
            </div>
          </div>
        </div>

        <p className="text-xs text-center text-gray-500 pt-4">
          ★ Verified customer ratings and reviews will be gathered directly from patrons and published post-commercial launch.
        </p>
      </section>

      {/* 9. CURATED FREQUENTLY ASKED QUESTIONS ACCORDION (ALL 7 FAQS) */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-10 space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#8c6027] dark:text-[#dfb983]">
            Common Inquiries
          </span>
          <h2 className="font-serif text-3xl font-bold text-[#401010] dark:text-[#f7ebd9]">
            Questions About Bambaura 9X
          </h2>
        </div>

        <div className="space-y-3">
          {FAQS_DATA.map((faq, idx) => {
            const isOpen = activeFaqIndex === idx
            return (
              <div
                key={idx}
                className="rounded-2xl border border-[#e6d8c4] dark:border-[#381616] bg-white dark:bg-[#180707] overflow-hidden transition-all shadow-xs"
              >
                <button
                  type="button"
                  onClick={() => setActiveFaqIndex(isOpen ? -1 : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-serif font-bold text-sm sm:text-base text-[#401010] dark:text-[#f7ebd9]"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#b28346] shrink-0 transition-transform duration-300 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      className="px-5 pb-5 text-xs sm:text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed border-t border-[#e6d8c4]/40 dark:border-[#381616]/40 pt-3"
                    >
                      {faq.a}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )
          })}
        </div>
      </section>

      {/* 10. CULINARY PARTNER BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="p-8 sm:p-10 rounded-3xl bg-[#401010] dark:bg-[#180707] border border-[#b28346]/30 text-[#f7ebd9] flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-2 text-center md:text-left">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#dfb983]">
              {HOME_DATA.ambassadorBanner?.badge || 'Culinary Creators & Chefs'}
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white">
              {HOME_DATA.ambassadorBanner?.title || 'Share the Bambaura Story'}
            </h3>
            <p className="text-xs text-amber-200/80 max-w-lg">
              {HOME_DATA.ambassadorBanner?.description || 'Join our Culinary Partner Circle to share authentic traditional bamboo roasted salt with food enthusiasts and home cooks.'}
            </p>
          </div>

          <Link
            to="/affiliate"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-[#dfb983] text-[#120404] hover:bg-[#eed2a9] font-bold text-xs uppercase tracking-wider transition-colors shadow-md shrink-0"
          >
            <span>Learn About Partner Program</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

    </div>
  )
}
