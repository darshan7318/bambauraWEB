import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X, ShieldCheck, CheckCircle2, Lock, CreditCard, Smartphone,
  Building, ChevronRight, Sparkles, Printer, ArrowRight, User,
  Mail, MapPin, Phone, Shield, Info, AlertCircle
} from 'lucide-react'
import { useStore } from '../context/StoreContext'

export default function RazorpayModal() {
  const {
    isRazorpayModalOpen,
    setIsRazorpayModalOpen,
    checkoutPayload,
    user,
    countryConfig,
    formatPrice,
    clearCart,
    showToast
  } = useStore()

  const [paymentMode, setPaymentMode] = useState('sdk') // 'sdk' | 'upi' | 'card' | 'netbanking'
  const [upiId, setUpiId] = useState('')
  const [selectedUpiApp, setSelectedUpiApp] = useState('gpay')
  const [cardNumber, setCardNumber] = useState('')
  const [cardExpiry, setCardExpiry] = useState('')
  const [cardCvv, setCardCvv] = useState('')
  const [cardName, setCardName] = useState(user ? user.name : '')
  const [selectedBank, setSelectedBank] = useState('HDFC Bank')

  // Customer Delivery Info
  const [customerName, setCustomerName] = useState(user?.name || '')
  const [customerEmail, setCustomerEmail] = useState(user?.email || '')
  const [customerPhone, setCustomerPhone] = useState('')
  const [customerAddress, setCustomerAddress] = useState('')
  const [customerCity, setCustomerCity] = useState(countryConfig?.name || '')

  const [isProcessing, setIsProcessing] = useState(false)
  const [confirmedOrder, setConfirmedOrder] = useState(null)

  // Accessible Escape Key Handler
  useEffect(() => {
    function handleKeyDown(e) {
      if (e.key === 'Escape' && isRazorpayModalOpen) {
        handleClose()
      }
    }
    if (isRazorpayModalOpen) {
      window.addEventListener('keydown', handleKeyDown)
      document.body.style.overflow = 'hidden'
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = ''
    }
  }, [isRazorpayModalOpen])

  if (!isRazorpayModalOpen) return null

  const items = checkoutPayload?.items || []
  const subtotalUSD = checkoutPayload?.totalUSD || 0
  const freeShipThresholdUSD = countryConfig.freeShip / countryConfig.rate
  const isFreeShip = subtotalUSD >= freeShipThresholdUSD
  const shippingUSD = isFreeShip ? 0 : 8
  const totalUSD = subtotalUSD + shippingUSD

  const getCustomerPayload = () => ({
    name: customerName.trim() || user?.name || 'Client Demo Guest',
    email: customerEmail.trim() || user?.email || 'demo@bambaura.com',
    phone: customerPhone.trim() || null,
    shippingAddress: customerAddress.trim() || 'Sample Delivery Address (Client Demo)',
    city: customerCity.trim() || countryConfig.name,
    country: countryConfig.name
  })

  const getItemsPayload = () => items.map(it => ({
    productId: it.id || 'bambaura-9x-salt',
    title: it.title || 'Bambaura 9X Bamboo Roasted Salt',
    grams: it.grams || '100g',
    grind: it.grind || 'Fine Granules',
    priceUSD: it.priceUSD || 24,
    quantity: it.quantity || 1,
    image: it.image || '/images/extracted/bambaura_canister_front_100g.jpg'
  }))

  const handleStandardSdkPayment = async () => {
    setIsProcessing(true)
    const customer = getCustomerPayload()

    try {
      // Check if real live backend checkout is active
      const createRes = await fetch('/api/checkout/razorpay/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: getItemsPayload(),
          regionCode: countryConfig.code,
          customer,
          purchaseType: checkoutPayload?.purchaseType || 'onetime'
        })
      })

      if (createRes.ok) {
        const orderData = await createRes.json()
        const orderId = orderData?.orderId
        const razorpayKey = orderData?.razorpayKeyId

        // If official Razorpay SDK is available on window and a live key is present
        if (typeof window !== 'undefined' && window.Razorpay && razorpayKey && !razorpayKey.includes('test_bambaura')) {
          const options = {
            key: razorpayKey,
            amount: Math.round(totalUSD * countryConfig.rate * 100),
            currency: countryConfig.code,
            name: 'Bambaura 9X Salt',
            description: 'Bamboo Roasted Salt Order',
            image: '/images/extracted/b_mark_full.png',
            order_id: orderId,
            handler: async function (response) {
              await verifyProductionOrder(response, customer)
            },
            prefill: {
              name: customer.name,
              email: customer.email,
              contact: customer.phone || ''
            },
            theme: { color: '#401010' },
            modal: {
              ondismiss: () => setIsProcessing(false)
            }
          }
          const rzp = new window.Razorpay(options)
          rzp.open()
          return
        }
      }
      
      // Standalone / Demo Mode execution
      triggerDemoConfirmation(customer, 'DEMO_RAZORPAY_FLOW')
    } catch {
      triggerDemoConfirmation(customer, 'DEMO_FALLBACK_FLOW')
    }
  }

  const verifyProductionOrder = async (response, customer) => {
    try {
      const verifyRes = await fetch('/api/checkout/razorpay/verify-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: response.razorpay_order_id,
          razorpayPaymentId: response.razorpay_payment_id,
          razorpaySignature: response.razorpay_signature,
          paymentMethod: 'RAZORPAY_LIVE',
          regionCode: countryConfig.code,
          customer,
          items: getItemsPayload(),
          totalUSD
        })
      })

      if (verifyRes.ok) {
        const receipt = await verifyRes.json()
        setConfirmedOrder({
          isLive: true,
          orderId: receipt.orderId,
          paymentId: receipt.paymentId,
          date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          items,
          totalUSD,
          totalFormatted: receipt.formattedTotal || formatPrice(totalUSD),
          paymentMethod: 'Razorpay Verified Live',
          customer
        })
        clearCart()
        showToast('Payment verified successfully! Order placed.', 'success')
      } else {
        triggerDemoConfirmation(customer, 'DEMO_UNVERIFIED_KEY')
      }
    } catch {
      triggerDemoConfirmation(customer, 'DEMO_UNVERIFIED_NETWORK')
    } finally {
      setIsProcessing(false)
    }
  }

  const triggerDemoConfirmation = (customer, mode) => {
    // Client Demo Safe Confirmation (Clear distinction: NO real charges, NO fake orders)
    setConfirmedOrder({
      isLive: false,
      isDemo: true,
      demoReference: 'DEMO-PREVIEW-' + Math.floor(1000 + Math.random() * 9000),
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      items,
      totalUSD,
      totalFormatted: formatPrice(totalUSD),
      paymentMethod: `${mode === 'DEMO_RAZORPAY_FLOW' ? 'Razorpay' : paymentMode.toUpperCase()} (Client Demo Simulation)`,
      customer
    })
    setIsProcessing(false)
    showToast('Client demonstration preview completed. No funds were charged.', 'info')
  }

  const handleDirectFormPayment = (e) => {
    e.preventDefault()
    setIsProcessing(true)
    const customer = getCustomerPayload()
    setTimeout(() => {
      triggerDemoConfirmation(customer, paymentMode.toUpperCase())
    }, 600)
  }

  const handleClose = () => {
    setConfirmedOrder(null)
    setIsRazorpayModalOpen(false)
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="checkout-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) handleClose()
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 15 }}
        className="relative w-full max-w-xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#401414] rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* HEADER */}
        <div className="bg-[#401010] dark:bg-[#120404] text-[#f7ebd9] px-6 py-4 flex items-center justify-between border-b border-[#b28346]/30">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow">
              R
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span id="checkout-modal-title" className="font-semibold text-sm tracking-wide">
                  Checkout &amp; Reserve Order
                </span>
                <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-xs font-mono font-bold">
                  Demo Mode
                </span>
              </div>
              <p className="text-xs text-amber-200/80">Bambaura 9X Bamboo Roasted Salt</p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleClose}
            aria-label="Close checkout modal"
            className="p-1.5 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* DEMO MODE NOTICE STRIP */}
        <div className="bg-amber-500/10 border-b border-amber-500/20 px-6 py-2.5 flex items-center gap-2 text-xs text-[#8c6027] dark:text-[#dfb983]">
          <Info className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400" />
          <span>
            <strong>Client Demonstration Environment:</strong> No real payment will be charged and no physical order will be placed.
          </span>
        </div>

        {/* CONTENT BODY */}
        <div className="p-6 overflow-y-auto space-y-6">
          {!confirmedOrder ? (
            <>
              {/* ORDER SUMMARY STRIP */}
              <div className="p-4 rounded-2xl bg-[#faf5ee] dark:bg-[#220c0c] border border-[#e6d8c4] dark:border-[#381616] flex items-center justify-between">
                <div>
                  <p className="text-xs text-[#8c6027] dark:text-[#dfb983] uppercase tracking-wider font-semibold">
                    Amount Due ({countryConfig.code})
                  </p>
                  <p className="font-serif text-2xl font-bold text-[#401010] dark:text-[#f7ebd9]">
                    {formatPrice(totalUSD)}
                  </p>
                  <p className="text-xs text-[#6b534b] dark:text-[#c2ada4]">
                    {items.length} Item{items.length !== 1 ? 's' : ''} • {isFreeShip ? 'Complimentary Insured Delivery' : 'Standard Shipping'}
                  </p>
                </div>
                {user && (
                  <div className="flex items-center gap-2 bg-white dark:bg-[#190909] px-3 py-1.5 rounded-xl border border-[#e6d8c4] dark:border-[#381616]">
                    <img src={user.avatar} alt={user.name} className="w-6 h-6 rounded-full" />
                    <span className="text-xs font-medium text-[#401010] dark:text-[#f7ebd9] max-w-[100px] truncate">
                      {user.name}
                    </span>
                  </div>
                )}
              </div>

              {/* PATRON DELIVERY INFORMATION */}
              <div className="p-4 rounded-2xl bg-[#faf5ee]/60 dark:bg-[#1c0808] border border-[#e6d8c4] dark:border-[#381616] space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-[#401010] dark:text-[#dfb983] flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#b28346]" />
                  <span>Delivery Destination</span>
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs font-medium text-[#6b534b] dark:text-[#c2ada4] mb-1">
                      Recipient Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Master Chef Julian"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-[#e6d8c4] dark:border-[#381616] bg-white dark:bg-[#250d0d] text-xs text-[#401010] dark:text-[#f7ebd9] focus:outline-none focus:border-[#b28346]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#6b534b] dark:text-[#c2ada4] mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      placeholder="patron@domain.com"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-[#e6d8c4] dark:border-[#381616] bg-white dark:bg-[#250d0d] text-xs text-[#401010] dark:text-[#f7ebd9] focus:outline-none focus:border-[#b28346]"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-[#6b534b] dark:text-[#c2ada4] mb-1">
                      Shipping Street Address
                    </label>
                    <input
                      type="text"
                      placeholder="Street Address, City, Postal Code"
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-[#e6d8c4] dark:border-[#381616] bg-white dark:bg-[#250d0d] text-xs text-[#401010] dark:text-[#f7ebd9] focus:outline-none focus:border-[#b28346]"
                    />
                  </div>
                </div>
              </div>

              {/* PAYMENT OPTION SELECTOR */}
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-[#401010] dark:text-[#dfb983] mb-3">
                  Demonstration Payment Method
                </p>

                <div className="grid grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMode('sdk')}
                    className={`p-2.5 rounded-2xl border text-center transition-all ${
                      paymentMode === 'sdk'
                        ? 'border-[#b28346] bg-[#faf5ee] dark:bg-[#2d1212] font-semibold text-[#401010] dark:text-[#f7ebd9] shadow-sm'
                        : 'border-[#e6d8c4] dark:border-[#381616] text-[#6b534b] dark:text-[#c2ada4] hover:bg-black/5'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 mx-auto mb-1 text-[#b28346]" />
                    <span className="text-xs block font-medium">Gateway SDK</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMode('upi')}
                    className={`p-2.5 rounded-2xl border text-center transition-all ${
                      paymentMode === 'upi'
                        ? 'border-[#b28346] bg-[#faf5ee] dark:bg-[#2d1212] font-semibold text-[#401010] dark:text-[#f7ebd9] shadow-sm'
                        : 'border-[#e6d8c4] dark:border-[#381616] text-[#6b534b] dark:text-[#c2ada4] hover:bg-black/5'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 mx-auto mb-1 text-[#b28346]" />
                    <span className="text-xs block font-medium">UPI App</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMode('card')}
                    className={`p-2.5 rounded-2xl border text-center transition-all ${
                      paymentMode === 'card'
                        ? 'border-[#b28346] bg-[#faf5ee] dark:bg-[#2d1212] font-semibold text-[#401010] dark:text-[#f7ebd9] shadow-sm'
                        : 'border-[#e6d8c4] dark:border-[#381616] text-[#6b534b] dark:text-[#c2ada4] hover:bg-black/5'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 mx-auto mb-1 text-[#b28346]" />
                    <span className="text-xs block font-medium">Card Flow</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMode('netbanking')}
                    className={`p-2.5 rounded-2xl border text-center transition-all ${
                      paymentMode === 'netbanking'
                        ? 'border-[#b28346] bg-[#faf5ee] dark:bg-[#2d1212] font-semibold text-[#401010] dark:text-[#f7ebd9] shadow-sm'
                        : 'border-[#e6d8c4] dark:border-[#381616] text-[#6b534b] dark:text-[#c2ada4] hover:bg-black/5'
                    }`}
                  >
                    <Building className="w-4 h-4 mx-auto mb-1 text-[#b28346]" />
                    <span className="text-xs block font-medium">NetBanking</span>
                  </button>
                </div>
              </div>

              {/* DEMO ACTION BUTTON */}
              <div className="space-y-3">
                <button
                  type="button"
                  onClick={paymentMode === 'sdk' ? handleStandardSdkPayment : handleDirectFormPayment}
                  disabled={isProcessing}
                  className="w-full py-4 rounded-2xl bg-[#401010] hover:bg-[#300c0c] dark:bg-[#dfb983] dark:hover:bg-[#d0a76c] text-[#f7ebd9] dark:text-[#140707] font-semibold text-sm tracking-wider uppercase transition-all flex items-center justify-center gap-2 shadow-xl disabled:opacity-50"
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      <span>Simulating Demo Flow...</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4" />
                      <span>Simulate Demo Order — {formatPrice(totalUSD)}</span>
                    </div>
                  )}
                </button>

                <p className="text-xs text-center text-gray-500">
                  🔒 Demonstration checkout simulation. Safe for client presentations.
                </p>
              </div>
            </>
          ) : (
            /* DEMONSTRATION ORDER CONFIRMATION VIEW */
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 rounded-full bg-amber-100 dark:bg-amber-950/60 text-[#b28346] dark:text-[#dfb983] flex items-center justify-center mx-auto shadow-lg">
                <Sparkles className="w-8 h-8" />
              </div>

              <div>
                <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-400 text-xs font-semibold tracking-wider uppercase font-mono">
                  [Demo Preview Receipt — Not a Real Charge]
                </span>
                <h3 className="font-serif text-3xl font-bold text-[#401010] dark:text-[#f7ebd9] mt-2">
                  Demonstration Order Preview
                </h3>
                <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-1 max-w-sm mx-auto">
                  This screen demonstrates the patron order receipt interface. In production, this receipt reflects live gateway settlement and courier tracking.
                </p>
              </div>

              {/* RECEIPT SUMMARY CARD */}
              <div className="p-5 rounded-2xl bg-[#faf5ee] dark:bg-[#220c0c] border border-[#e6d8c4] dark:border-[#381616] text-left text-xs space-y-3">
                <div className="flex justify-between border-b border-[#e6d8c4]/60 dark:border-[#381616] pb-2">
                  <span className="text-[#6b534b] dark:text-[#c2ada4]">Demo Simulation ID</span>
                  <span className="font-mono font-bold text-[#401010] dark:text-[#dfb983]">{confirmedOrder.demoReference || 'DEMO-PREVIEW'}</span>
                </div>
                <div className="flex justify-between border-b border-[#e6d8c4]/60 dark:border-[#381616] pb-2">
                  <span className="text-[#6b534b] dark:text-[#c2ada4]">Payment Mode</span>
                  <span className="font-semibold text-[#401010] dark:text-[#f7ebd9]">{confirmedOrder.paymentMethod}</span>
                </div>
                <div className="flex justify-between border-b border-[#e6d8c4]/60 dark:border-[#381616] pb-2">
                  <span className="text-[#6b534b] dark:text-[#c2ada4]">Recipient</span>
                  <span className="font-semibold text-[#401010] dark:text-[#f7ebd9]">{confirmedOrder.customer.name}</span>
                </div>
                <div className="flex justify-between border-b border-[#e6d8c4]/60 dark:border-[#381616] pb-2">
                  <span className="text-[#6b534b] dark:text-[#c2ada4]">Destination</span>
                  <span className="text-gray-500 truncate max-w-[220px]">{confirmedOrder.customer.shippingAddress}</span>
                </div>
                <div className="flex justify-between font-bold text-sm text-[#401010] dark:text-[#dfb983] pt-1">
                  <span>Demo Total</span>
                  <span>{confirmedOrder.totalFormatted}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex-1 py-3 rounded-xl border border-[#e6d8c4] dark:border-[#381616] text-xs font-semibold text-[#401010] dark:text-[#f7ebd9] flex items-center justify-center gap-1.5 hover:bg-black/5"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Preview</span>
                </button>
                <button
                  type="button"
                  onClick={handleClose}
                  className="flex-1 py-3 rounded-xl bg-[#401010] dark:bg-[#dfb983] text-[#f7ebd9] dark:text-[#140707] text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md"
                >
                  <span>Close Preview</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* FOOTER BADGE */}
        <div className="px-6 py-3 bg-[#faf5ee] dark:bg-[#120404] border-t border-[#e6d8c4] dark:border-[#381616] flex items-center justify-between text-xs text-[#6b534b] dark:text-[#c2ada4]">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            Client Demo Protected Interface
          </span>
          <span>Zero Live Charges</span>
        </div>
      </motion.div>
    </div>
  )
}
