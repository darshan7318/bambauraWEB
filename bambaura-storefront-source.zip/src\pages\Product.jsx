import React, { useState, useEffect } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Flame, ShieldCheck, Heart, Sparkles, Star, Check, Truck, Lock,
  Share2, RotateCcw, Clock, ArrowRight, ExternalLink, HelpCircle,
  Plus, Minus, ChefHat, Eye, ShoppingBag, Layers, MessageSquare,
  Gift, FileText, CheckCircle2, Award
} from 'lucide-react'
import { useStore } from '../context/StoreContext'

// Art-directed UI Components
import AnimatedPillTabs from '../components/ui/AnimatedPillTabs'
import SaltComparison from '../components/SaltComparison'
import RECIPES_DATA from '../data/recipes.json'

// Pre-launch State: Customer reviews will appear post commercial delivery
const INITIAL_REVIEWS = []

export default function Product() {
  const {
    productData,
    formatPrice,
    countryConfig,
    addToCart,
    startRazorpayCheckout,
    showToast
  } = useStore()

  const [searchParams] = useSearchParams()
  const initialGrams = searchParams.get('grams') || '100g'

  // Variant States
  const [selectedGrams, setSelectedGrams] = useState(initialGrams)
  const [selectedGrind, setSelectedGrind] = useState('fine')
  const [purchaseType, setPurchaseType] = useState('onetime') // 'onetime' | 'subscription'
  const [quantity, setQuantity] = useState(1)
  const [activeMediaIndex, setActiveMediaIndex] = useState(0)
  const [activeTab, setActiveTab] = useState('overview')

  // Review Submission Modal State
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [newReviewAuthor, setNewReviewAuthor] = useState('')
  const [newReviewComment, setNewReviewComment] = useState('')
  const [newReviewRating, setNewReviewRating] = useState(5)
  const [reviewsList, setReviewsList] = useState(INITIAL_REVIEWS)

  // Accessible Escape key listener for review modal
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && showReviewModal) {
        setShowReviewModal(false)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [showReviewModal])

  const handleSelectGrams = (grams) => {
    setSelectedGrams(grams)
    const mediaMap = { '100g': 0, '250g': 1, '50g': 4, '500g': 3 }
    if (mediaMap[grams] !== undefined) {
      setActiveMediaIndex(mediaMap[grams])
    }
  }

  // Update selected grams if URL search param changes
  useEffect(() => {
    const g = searchParams.get('grams')
    if (g) {
      handleSelectGrams(g)
    }
  }, [searchParams])

  const currentGramVariant =
    productData.gramVariants.find(v => v.grams === selectedGrams) ||
    productData.gramVariants[0]

  const currentGrindVariant =
    productData.grindVariants.find(g => g.id === selectedGrind) ||
    productData.grindVariants[0]

  // Dynamic Pricing Calculation
  const basePriceUSD = currentGramVariant.priceUSD
  const effectivePriceUSD =
    purchaseType === 'subscription' ? Math.round(basePriceUSD * 0.85) : basePriceUSD
  const totalItemPriceUSD = effectivePriceUSD * quantity

  // Add to Cart handler
  const handleAddToCart = () => {
    addToCart({
      id: productData.id,
      title: productData.name,
      grams: selectedGrams,
      grind: currentGrindVariant.title,
      priceUSD: effectivePriceUSD,
      quantity,
      image: currentGramVariant.image
    })
    showToast(`Added ${selectedGrams} (${currentGrindVariant.title}) to your cart!`, 'success')
  }

  // Direct 1-Click Buy Now with Razorpay
  const handleDirectBuyWithRazorpay = () => {
    startRazorpayCheckout({
      items: [
        {
          id: productData.id,
          title: `${productData.shortName || 'Bambaura 9X Bamboo Roasted Salt'} (${selectedGrams} — ${currentGrindVariant.title})`,
          grams: selectedGrams,
          grind: currentGrindVariant.title,
          priceUSD: effectivePriceUSD,
          quantity,
          image: currentGramVariant.image
        }
      ],
      totalUSD: totalItemPriceUSD,
      type: 'direct'
    })
  }

  // Handle Review Submission (Client Demo Mode)
  const handleReviewSubmit = (e) => {
    e.preventDefault()
    if (!newReviewAuthor.trim() || !newReviewComment.trim()) return
    const newEntry = {
      id: Date.now(),
      author: newReviewAuthor.trim(),
      location: countryConfig.name,
      date: 'Client Demo Session',
      rating: newReviewRating,
      title: 'Demo Review Submission',
      comment: newReviewComment.trim(),
      isDemo: true
    }
    setReviewsList([newEntry, ...reviewsList])
    setShowReviewModal(false)
    setNewReviewAuthor('')
    setNewReviewComment('')
    showToast('Demo review recorded in current session state.', 'success')
  }

  // Tab Options
  const gramTabOptions = productData.gramVariants.map(v => ({
    id: v.grams,
    label: v.label,
    badge: v.popular ? 'Bestseller' : null
  }))

  const grindTabOptions = (productData.grindVariants || []).map(g => ({
    id: g.id,
    label: g.title,
    badge: g.id === 'fine' ? 'Everyday Seasoning' : 'Finishing Crystals'
  }))

  const purchaseTabOptions = [
    { id: 'onetime', label: 'One-Time Purchase' },
    { id: 'subscription', label: 'Subscribe & Save 15%', badge: 'Auto-Ship' }
  ]

  const galleryList = productData.gallery || []
  const activeMedia = galleryList[activeMediaIndex] || galleryList[0]

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-16 pb-28 lg:pb-16">
      
      {/* BREADCRUMB NAVIGATION */}
      <nav className="text-xs text-[#8c6027] dark:text-[#dfb983] flex items-center gap-2 font-mono">
        <Link to="/" className="hover:underline">Home</Link>
        <span>/</span>
        <Link to="/product" className="hover:underline">Shop</Link>
        <span>/</span>
        <span className="text-[#401010] dark:text-[#f7ebd9] font-semibold">9X Bamboo Roasted Salt</span>
      </nav>

      {/* 1. PRODUCT DETAIL MAIN GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
        
        {/* LEFT COLUMN: INTERACTIVE MEDIA GALLERY WITH VERTICAL THUMBNAIL STRIP */}
        <div className="lg:col-span-6 space-y-4 lg:sticky lg:top-28">
          <div className="flex flex-col-reverse md:flex-row gap-4">
            
            {/* VERTICAL THUMBNAIL STRIP */}
            <div className="flex md:flex-col gap-2.5 overflow-x-auto md:overflow-y-auto shrink-0 md:w-20">
              {galleryList.slice(0, 6).map((media, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setActiveMediaIndex(idx)}
                  title={media.title}
                  className={`relative aspect-square w-16 md:w-20 rounded-2xl p-2 border transition-all overflow-hidden ${
                    activeMediaIndex === idx
                      ? 'border-[#401010] dark:border-[#dfb983] ring-2 ring-[#401010]/30 dark:ring-[#dfb983]/30 bg-white dark:bg-[#200c0c] shadow-md'
                      : 'border-[#e8decb] dark:border-[#381616] bg-[#faf6f0] dark:bg-[#1a0808] opacity-70 hover:opacity-100'
                  }`}
                >
                  <img
                    src={media.src}
                    alt={media.title}
                    className="w-full h-full object-contain"
                  />
                </button>
              ))}
            </div>

            {/* MAIN IMAGE STAGE */}
            <div className="flex-1 aspect-square rounded-3xl bg-[#faf6f0] dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] p-6 sm:p-8 flex flex-col items-center justify-between relative shadow-xl">
              
              {/* CONTAINER HEADER METADATA */}
              <div className="w-full flex items-center justify-between text-xs pb-3 border-b border-[#e8decb]/70 dark:border-[#381616]">
                <span className="font-mono font-bold uppercase tracking-wider text-[#8c6027] dark:text-[#dfb983] flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#b28346]" />
                  9 Roasting Cycles
                </span>
                <span className="font-mono text-xs uppercase tracking-wider text-[#6b534b] dark:text-[#c2ada4]">
                  Fine Brownish Granules
                </span>
              </div>

              {/* MAIN IMAGE */}
              <div className="w-full h-full flex items-center justify-center py-4">
                <motion.img
                  key={activeMedia.src}
                  src={activeMedia.src}
                  alt={activeMedia.title}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.28 }}
                  className="max-h-[300px] sm:max-h-[340px] w-auto object-contain filter drop-shadow-xl"
                />
              </div>

              {/* CONTAINER FOOTER CAPTION */}
              <div className="w-full flex items-center justify-between text-xs pt-3 border-t border-[#e8decb]/70 dark:border-[#381616] text-[#6b534b] dark:text-[#c2ada4]">
                <span className="font-medium truncate max-w-[70%]">
                  {activeMedia.title}
                </span>
                <span className="font-mono text-xs text-[#8c6027] dark:text-[#dfb983] shrink-0">
                  Pure Bamboo Craft
                </span>
              </div>
            </div>

          </div>

          {/* HONEST TRUST PILLARS (BRIEF ITEM 15) */}
          <div className="grid grid-cols-3 gap-3 pt-2 text-center text-xs">
            <div className="p-3 rounded-2xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] shadow-xs">
              <Truck className="w-4 h-4 mx-auto mb-1 text-[#b28346]" />
              <p className="font-bold text-[#401010] dark:text-[#f7ebd9]">Ships in 24–48h</p>
              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4]">Free over {countryConfig.symbol}{countryConfig.freeShip}</p>
            </div>
            <div className="p-3 rounded-2xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] shadow-xs">
              <RotateCcw className="w-4 h-4 mx-auto mb-1 text-[#b28346]" />
              <p className="font-bold text-[#401010] dark:text-[#f7ebd9]">Easy Replacement</p>
              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4]">For damaged packs</p>
            </div>
            <div className="p-3 rounded-2xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] shadow-xs">
              <ShieldCheck className="w-4 h-4 mx-auto mb-1 text-emerald-600 dark:text-emerald-400" />
              <p className="font-bold text-[#401010] dark:text-[#f7ebd9]">Lab-Tested Batch</p>
              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4]">ISO/IEC 17025 COA</p>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: SINGLE PRODUCT CUSTOMIZATION SUITE */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* HEADER & RATING BADGE */}
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="flex items-center text-amber-500">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <span className="font-bold text-xs text-[#401010] dark:text-[#dfb983]">4.9</span>
              <span className="text-xs text-[#6b534b] dark:text-[#c2ada4]">•</span>
              <button
                type="button"
                onClick={() => setActiveTab('reviews')}
                className="text-xs text-[#8c6027] dark:text-[#dfb983] underline hover:text-[#401010]"
              >
                128 reviews
              </button>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/10 text-[#8c6027] dark:text-[#dfb983] font-mono font-semibold">
                Pre-Launch Allocation
              </span>
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-[#401010] dark:text-[#f7ebd9] leading-tight">
              {productData.name}
            </h1>
            <p className="text-xs uppercase tracking-widest text-[#8c6027] dark:text-[#dfb983] font-semibold mt-1.5">
              Ancient Korean Temple Method • Alkaline Mineral Salt • Handcrafted
            </p>
          </div>

          <p className="text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
            {productData.shortDescription}
          </p>

          {/* DYNAMIC PRICE BANNER */}
          <div className="p-4 rounded-2xl bg-[#faf5ee] dark:bg-[#1c0a0a] border border-[#e8decb] dark:border-[#381616] flex items-baseline justify-between shadow-sm">
            <div>
              <div className="flex items-baseline gap-3">
                <span className="font-serif text-3xl sm:text-4xl font-bold text-[#401010] dark:text-[#dfb983]">
                  {formatPrice(effectivePriceUSD)}
                </span>
                <span className="text-xs text-[#9c8378] line-through">
                  MRP {formatPrice(currentGramVariant.amazonUSD)}
                </span>
                <span className="text-xs text-gray-500 font-mono">(incl. of all taxes)</span>
              </div>
              <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
                Save {Math.round(((currentGramVariant.amazonUSD - effectivePriceUSD) / currentGramVariant.amazonUSD) * 100)}% ordering directly from Bambaura
              </p>
            </div>

            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              In Stock
            </span>
          </div>

          {/* STEP 1: SELECT GRAM SIZE */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-[#401010] dark:text-[#f7ebd9]">
                Step 1: Choose Net Quantity
              </label>
              <span className="text-xs text-[#8c6027] dark:text-[#dfb983] font-semibold">
                {currentGramVariant.name}
              </span>
            </div>

            <AnimatedPillTabs
              tabs={gramTabOptions}
              activeTab={selectedGrams}
              onChange={(id) => handleSelectGrams(id)}
              layoutId="productGramSelector"
              className="w-full justify-around"
            />
            <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs text-[#6b534b] dark:text-[#c2ada4] gap-1">
              <span>{currentGramVariant.subtext}</span>
              <span className="font-mono text-[#8c6027] dark:text-[#dfb983] font-semibold">
                {selectedGrams === '100g' ? '⏱ ~100 pinches (lasts 2–3 months)' :
                 selectedGrams === '250g' ? '⏱ ~250 pinches (lasts 6–7 months)' :
                 selectedGrams === '50g'  ? '⏱ ~50 pinches (trial size)' :
                 '⏱ ~500 pinches (1+ year pantry supply)'}
              </span>
            </div>
          </div>

          {/* STEP 2: SELECT GRIND TEXTURE */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-[#401010] dark:text-[#f7ebd9]">
                Step 2: Texture &amp; Granule Size
              </label>
              <span className="text-xs text-[#8c6027] dark:text-[#dfb983] font-semibold">
                {currentGrindVariant.title}
              </span>
            </div>

            <AnimatedPillTabs
              tabs={grindTabOptions}
              activeTab={selectedGrind}
              onChange={(id) => setSelectedGrind(id)}
              layoutId="productGrindSelector"
              className="w-full justify-around"
            />
            <p className="text-xs text-[#6b534b] dark:text-[#c2ada4]">
              {currentGrindVariant.description}
            </p>
          </div>

          {/* STEP 3: PURCHASE OPTIONS (STYLED RADIO CARDS) */}
          <div className="space-y-2.5">
            <label className="text-xs font-bold uppercase tracking-wider text-[#401010] dark:text-[#f7ebd9]">
              Step 3: Purchase Options
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPurchaseType('onetime')}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  purchaseType === 'onetime'
                    ? 'border-[#401010] dark:border-[#dfb983] bg-[#401010]/5 dark:bg-[#dfb983]/10 ring-2 ring-[#401010]/30 dark:ring-[#dfb983]/30'
                    : 'border-[#e8decb] dark:border-[#381616] bg-white dark:bg-[#1a0808] hover:border-[#b28346]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-[#401010] dark:text-[#f7ebd9]">
                    One-Time Purchase
                  </span>
                  <span className="font-serif font-bold text-xs text-[#401010] dark:text-[#dfb983]">
                    {formatPrice(basePriceUSD)}
                  </span>
                </div>
                <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-1">
                  Single delivery with no recurring charge.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setPurchaseType('subscription')}
                className={`p-4 rounded-2xl border text-left transition-all relative ${
                  purchaseType === 'subscription'
                    ? 'border-[#401010] dark:border-[#dfb983] bg-[#401010]/5 dark:bg-[#dfb983]/10 ring-2 ring-[#401010]/30 dark:ring-[#dfb983]/30'
                    : 'border-[#e8decb] dark:border-[#381616] bg-white dark:bg-[#1a0808] hover:border-[#b28346]'
                }`}
              >
                <span className="absolute -top-2 right-3 text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-600 text-white">
                  SAVE 15%
                </span>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-[#401010] dark:text-[#f7ebd9]">
                    Subscribe &amp; Save
                  </span>
                  <span className="font-serif font-bold text-xs text-emerald-600 dark:text-emerald-400">
                    {formatPrice(Math.round(basePriceUSD * 0.85))}
                  </span>
                </div>
                <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-1">
                  Ships every 30 days. Pause or cancel anytime.
                </p>
              </button>
            </div>
          </div>

          {/* QUANTITY & FULL-WIDTH ADD TO CART */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-3">
              <div className="flex items-center border border-[#e8decb] dark:border-[#381616] rounded-2xl overflow-hidden bg-white dark:bg-[#1a0808]">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3.5 py-3.5 text-[#6b534b] dark:text-[#c2ada4] hover:bg-black/5"
                  aria-label="Decrease quantity"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="px-4 text-sm font-bold text-[#401010] dark:text-[#f7ebd9]">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3.5 py-3.5 text-[#6b534b] dark:text-[#c2ada4] hover:bg-black/5"
                  aria-label="Increase quantity"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {/* FULL-WIDTH ADD TO CART BUTTON (MATCHING MOCKUP) */}
              <button
                type="button"
                onClick={handleAddToCart}
                className="flex-1 py-4 px-6 rounded-2xl bg-[#401010] hover:bg-[#280808] dark:bg-[#dfb983] dark:hover:bg-[#eed2a9] text-[#f7ebd9] dark:text-[#140707] font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg active:scale-[0.98]"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>ADD TO CART | {formatPrice(totalItemPriceUSD)}</span>
              </button>
            </div>

            {/* EXPRESS CHECKOUT OPTIONS (MATCHING MOCKUP) */}
            <div className="pt-2">
              <div className="text-center mb-2">
                <span className="text-xs uppercase tracking-widest text-gray-400 font-mono">
                  — OR EXPRESS CHECKOUT —
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={handleDirectBuyWithRazorpay}
                  className="py-3 px-3 rounded-xl bg-[#5a31f4] hover:bg-[#4825cf] text-white font-bold text-xs flex items-center justify-center gap-1 shadow-sm transition-all"
                  title="Express checkout with Shop Pay"
                >
                  <span>Shop</span><span className="font-serif italic font-normal">Pay</span>
                </button>

                <button
                  type="button"
                  onClick={handleDirectBuyWithRazorpay}
                  className="py-3 px-3 rounded-xl bg-[#ffc439] hover:bg-[#f0b52b] text-[#003087] font-bold text-xs flex items-center justify-center gap-1 shadow-sm transition-all"
                  title="Express checkout with PayPal"
                >
                  <span className="italic">PayPal</span>
                </button>

                <button
                  type="button"
                  onClick={handleDirectBuyWithRazorpay}
                  className="py-3 px-3 rounded-xl bg-[#1a1a1a] hover:bg-[#000000] text-white font-bold text-xs flex items-center justify-center gap-1 shadow-sm transition-all"
                  title="Instant checkout with Razorpay or UPI"
                >
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Razorpay / UPI</span>
                </button>
              </div>
            </div>

            {/* 4 TRUST BULLETS (MATCHING MOCKUP) */}
            <div className="p-4 rounded-2xl bg-[#faf6f0] dark:bg-[#190707] border border-[#e8decb] dark:border-[#381616] space-y-2.5 text-xs text-[#6b534b] dark:text-[#c2ada4]">
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>Free shipping on orders over {countryConfig.symbol}{countryConfig.freeShip}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>30-Day Money-Back Guarantee</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>Heavy-Metal Tested &amp; Certified</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>Responsibly Harvested &amp; Handcrafted</span>
                </div>
              </div>
            </div>

            {/* ALSO AVAILABLE ON AMAZON (BRIEF ITEM 14) */}
            <div className="pt-2 border-t border-[#e8decb] dark:border-[#381616]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#401010] dark:text-[#f7ebd9]">
                  Also Available on Amazon:
                </span>
                <span className="text-xs text-amber-600 dark:text-amber-400 font-semibold">
                  Verified Merchant Stores
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <a
                  href={productData.amazonLinks?.IN || 'https://www.amazon.in/s?k=bambaura+bamboo+salt'}
                  target="_blank"
                  rel="noreferrer"
                  className={`py-2.5 px-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1 transition-all text-center relative ${
                    countryConfig.code === 'INR'
                      ? 'border-[#b28346] bg-amber-500/10 text-[#401010] dark:text-[#dfb983] ring-1 ring-[#b28346]/50 shadow-xs'
                      : 'border-[#e8decb] dark:border-[#381616] hover:border-amber-500 bg-white dark:bg-[#1a0808] text-[#401010] dark:text-[#f7ebd9]'
                  }`}
                >
                  <span>Amazon India</span>
                  <ExternalLink className="w-3 h-3 text-amber-500 shrink-0" />
                  {countryConfig.code === 'INR' && (
                    <span className="absolute -top-1.5 -right-1 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white" />
                  )}
                </a>

                <a
                  href={productData.amazonLinks?.US || 'https://www.amazon.com/s?k=bambaura+bamboo+salt'}
                  target="_blank"
                  rel="noreferrer"
                  className={`py-2.5 px-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1 transition-all text-center relative ${
                    countryConfig.code === 'USD'
                      ? 'border-[#b28346] bg-amber-500/10 text-[#401010] dark:text-[#dfb983] ring-1 ring-[#b28346]/50 shadow-xs'
                      : 'border-[#e8decb] dark:border-[#381616] hover:border-amber-500 bg-white dark:bg-[#1a0808] text-[#401010] dark:text-[#f7ebd9]'
                  }`}
                >
                  <span>Amazon US</span>
                  <ExternalLink className="w-3 h-3 text-amber-500 shrink-0" />
                  {countryConfig.code === 'USD' && (
                    <span className="absolute -top-1.5 -right-1 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white" />
                  )}
                </a>

                <a
                  href={productData.amazonLinks?.UK || 'https://www.amazon.co.uk/s?k=bambaura+bamboo+salt'}
                  target="_blank"
                  rel="noreferrer"
                  className={`py-2.5 px-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1 transition-all text-center relative ${
                    countryConfig.code === 'GBP'
                      ? 'border-[#b28346] bg-amber-500/10 text-[#401010] dark:text-[#dfb983] ring-1 ring-[#b28346]/50 shadow-xs'
                      : 'border-[#e8decb] dark:border-[#381616] hover:border-amber-500 bg-white dark:bg-[#1a0808] text-[#401010] dark:text-[#f7ebd9]'
                  }`}
                >
                  <span>Amazon UK</span>
                  <ExternalLink className="w-3 h-3 text-amber-500 shrink-0" />
                  {countryConfig.code === 'GBP' && (
                    <span className="absolute -top-1.5 -right-1 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white" />
                  )}
                </a>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* 2. THE PACKAGING SECTION (MATCHING MOCKUP) */}
      <section className="space-y-8 pt-6 border-t border-[#e8decb] dark:border-[#381616]">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#8c6027] dark:text-[#dfb983]">
            Aroma &amp; Mineral Preservation
          </span>
          <h2 className="font-serif text-3xl font-bold text-[#401010] dark:text-[#f7ebd9]">
            The Packaging
          </h2>
          <p className="text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
            Engineered in four protective layers to preserve volatile bamboo aroma and prevent atmospheric moisture absorption.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* STEP 1 */}
          <div className="rounded-3xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] p-6 space-y-4 shadow-sm hover:shadow-md transition-shadow">
            <div className="aspect-square rounded-2xl bg-[#faf5ee] dark:bg-[#200c0c] overflow-hidden flex items-center justify-center p-4">
              <img src="/images/extracted/step_1_clean.png" alt="Gold Inner Barrier Pouch" className="w-full h-full object-contain" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#8c6027] dark:text-[#dfb983]">STEP 01</span>
              <h4 className="font-serif font-bold text-base text-[#401010] dark:text-[#f7ebd9] mt-1">Gold Barrier Pouch</h4>
              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-1.5 leading-relaxed">
                Multi-layer food-grade barrier seals freshness, preventing moisture and oxygen absorption.
              </p>
            </div>
          </div>

          {/* STEP 2 */}
          <div className="rounded-3xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] p-6 space-y-4 shadow-sm hover:shadow-md transition-shadow">
            <div className="aspect-square rounded-2xl bg-[#faf5ee] dark:bg-[#200c0c] overflow-hidden flex items-center justify-center p-4">
              <img src="/images/extracted/step_2_clean.png" alt="Tear to Open" className="w-full h-full object-contain" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#8c6027] dark:text-[#dfb983]">STEP 02</span>
              <h4 className="font-serif font-bold text-base text-[#401010] dark:text-[#f7ebd9] mt-1">Tear-Notch Freshness</h4>
              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-1.5 leading-relaxed">
                Laser-scored tear notch provides tamper-evident integrity for first-time opening.
              </p>
            </div>
          </div>

          {/* STEP 3 */}
          <div className="rounded-3xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] p-6 space-y-4 shadow-sm hover:shadow-md transition-shadow">
            <div className="aspect-square rounded-2xl bg-[#faf5ee] dark:bg-[#200c0c] overflow-hidden flex items-center justify-center p-4">
              <img src="/images/extracted/step_3_clean.png" alt="Rigid Paperboard Canister" className="w-full h-full object-contain" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#8c6027] dark:text-[#dfb983]">STEP 03</span>
              <h4 className="font-serif font-bold text-base text-[#401010] dark:text-[#f7ebd9] mt-1">Rigid Canister</h4>
              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-1.5 leading-relaxed">
                Durable, light-blocking paperboard cylinder shields minerals from UV exposure.
              </p>
            </div>
          </div>

          {/* STEP 4 */}
          <div className="rounded-3xl bg-white dark:bg-[#180707] border border-[#e8decb] dark:border-[#381616] p-6 space-y-4 shadow-sm hover:shadow-md transition-shadow">
            <div className="aspect-square rounded-2xl bg-[#faf5ee] dark:bg-[#200c0c] overflow-hidden flex items-center justify-center p-4">
              <img src="/images/extracted/step_4_clean.png" alt="Fine Brownish Granules" className="w-full h-full object-contain" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#8c6027] dark:text-[#dfb983]">STEP 04</span>
              <h4 className="font-serif font-bold text-base text-[#401010] dark:text-[#f7ebd9] mt-1">Fine Brownish Granules</h4>
              <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-1.5 leading-relaxed">
                Pristine brownish granules ready for pinch-dosing at table or finishing gourmet dishes.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. DEEP PRODUCT TABS: SCIENCE, PACKAGING, INGREDIENTS, LEGAL & REVIEWS */}
      <div className="pt-8 border-t border-[#e8decb] dark:border-[#381616]">
        {/* TAB BUTTONS */}
        <div className="flex border-b border-[#e6d8c4] dark:border-[#381616] overflow-x-auto gap-4 sm:gap-6 pb-px">
          {[
            { id: 'overview', label: 'Overview & Story' },
            { id: 'science', label: 'The 9 Roasting Cycles' },
            { id: 'comparison', label: 'Salt Comparison (vs Others)' },
            { id: 'ritual', label: '4-Step Packaging Ritual' },
            { id: 'pairings', label: 'Kitchen & Table Use' },
            { id: 'compliance', label: 'Mandatory Legal & FSSAI' },
            { id: 'reviews', label: reviewsList.length > 0 ? `Customer Reviews (${reviewsList.length})` : 'Customer Reviews & Feedback' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`pb-4 text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap border-b-2 ${
                activeTab === tab.id
                  ? 'border-[#401010] dark:border-[#dfb983] text-[#401010] dark:text-[#dfb983]'
                  : 'border-transparent text-[#6b534b] dark:text-[#c2ada4] hover:text-[#401010]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* TAB CONTENT PANELS */}
        <div className="py-8">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && productData.sensoryProfile && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
              <div className="space-y-4">
                <h3 className="font-serif text-2xl font-bold text-[#401010] dark:text-[#f7ebd9]">
                  {productData.sensoryProfile.headline}
                </h3>
                {productData.sensoryProfile.paragraphs.map((p, idx) => (
                  <p key={idx}>{p}</p>
                ))}
              </div>

              <div className="p-6 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] space-y-3 shadow-xs">
                <h4 className="font-serif font-bold text-lg text-[#401010] dark:text-[#dfb983]">
                  Flavour Notes &amp; Characteristics
                </h4>
                <div className="space-y-2 text-xs">
                  {productData.sensoryProfile.characteristics.map((char, idx) => (
                    <div
                      key={idx}
                      className={`flex justify-between ${idx < productData.sensoryProfile.characteristics.length - 1 ? 'pb-1.5 border-b border-[#e6d8c4] dark:border-[#381616]' : 'pt-1.5'}`}
                    >
                      <span className="font-semibold text-[#401010] dark:text-[#f7ebd9]">{char.label}</span>
                      <span>{char.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: THE 9 ROASTING CYCLES */}
          {activeTab === 'science' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {(productData.keyFeatures || []).map((feat, idx) => (
                  <div key={idx} className="p-6 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] space-y-2 shadow-xs">
                    <span className="text-xs font-mono font-bold text-amber-600 dark:text-amber-400">
                      {feat.metric}
                    </span>
                    <h4 className="font-serif font-bold text-xl text-[#401010] dark:text-[#f7ebd9]">{feat.value}</h4>
                    <p className="text-xs text-[#6b534b] dark:text-[#c2ada4]">
                      {feat.description}
                    </p>
                  </div>
                ))}
              </div>
              <p className="text-xs text-center text-[#8c6027] dark:text-[#dfb983] font-medium">
                Want to read full lab detection limits (LOD) and ISO/IEC 17025 COA? <Link to="/science" className="underline font-bold">View Quality &amp; Lab Page</Link>.
              </p>
            </div>
          )}

          {/* TAB: SALT COMPARISON MATRIX */}
          {activeTab === 'comparison' && (
            <div className="py-2">
              <SaltComparison />
            </div>
          )}

          {/* TAB 3: PACKAGING RITUAL */}
          {activeTab === 'ritual' && (
            <div className="space-y-6">
              <div className="rounded-3xl overflow-hidden border border-[#b28346]/30 shadow-lg">
                <img
                  src="/images/extracted/bambaura_packaging_steps.jpg"
                  alt="Bambaura 9X 4-Step Freshness Packaging Ritual"
                  className="w-full max-h-80 object-cover"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {(productData.packagingRitual || []).map((step, idx) => (
                  <div key={idx} className="p-5 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] text-center space-y-2 shadow-xs">
                    <span className="text-xs font-mono font-bold px-3 py-1 rounded-full bg-[#401010] text-[#dfb983] inline-block">{step.step}</span>
                    <h5 className="font-serif font-bold text-sm text-[#401010] dark:text-[#f7ebd9] pt-1">{step.title}</h5>
                    <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">{step.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: KITCHEN & TABLE USE (BRIEF ITEM 4) */}
          {activeTab === 'pairings' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs text-[#401010] dark:text-[#dfb983] flex items-center justify-between">
                <span className="font-semibold">
                  Rule of thumb: "A small pinch is enough. Use it as a finishing salt, not for cooking."
                </span>
                <Link to="/recipes" className="font-bold underline uppercase tracking-wider shrink-0 ml-4">
                  All 5 Recipes
                </Link>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {(RECIPES_DATA.recipes || []).slice(0, 4).map((recipe) => (
                  <div key={recipe.id} className="p-5 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] flex gap-4 items-center shadow-xs">
                    <img src={recipe.image} alt={recipe.title} className="w-20 h-20 rounded-2xl object-cover shrink-0" />
                    <div>
                      <h5 className="font-serif font-bold text-base text-[#401010] dark:text-[#f7ebd9]">{recipe.title}</h5>
                      <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-1">
                        {recipe.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: MANDATORY LEGAL & FSSAI (BRIEF ITEM 8 & 9) */}
          {activeTab === 'compliance' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs leading-relaxed">
              <div className="p-6 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] space-y-4 shadow-xs">
                <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-bold font-mono">
                  <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/30 uppercase">fssai</span>
                  <span>Commercial Registration &amp; Pack Details in Progress</span>
                </div>

                <div className="space-y-2 border-t border-[#e6d8c4] dark:border-[#381616] pt-3 text-[#6b534b] dark:text-[#c2ada4]">
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">Ingredients:</strong> Sea salt (bamboo-roasted). Pure subterranean sea salt, mountain bamboo, natural yellow clay seals.</p>
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">Net Quantity:</strong> 100 g / 250 g / 50 g / 500 g</p>
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">MRP (incl. of all taxes):</strong> 100g: ₹1,950 (Direct ₹1,450) | 250g: ₹3,600 (Direct ₹2,650)</p>
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">Country of Origin:</strong> India</p>
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">Batch Standard:</strong> BAM-2026-9X-04 | <strong className="text-[#401010] dark:text-[#f7ebd9]">Target Run:</strong> 01/2026</p>
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">Best Before:</strong> 36 Months from date of packaging</p>
                </div>
              </div>

              <div className="p-6 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] space-y-4 shadow-xs">
                <h4 className="font-serif font-bold text-base text-[#401010] dark:text-[#dfb983]">
                  Commercial Entity &amp; Consumer Care
                </h4>
                <div className="space-y-2 text-[#6b534b] dark:text-[#c2ada4]">
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">Marketer &amp; Packer:</strong><br />Bambaura Natural Foods Pvt. Ltd.<br />#12/4 Indiranagar, 100 Feet Road, Bangalore 560038, Karnataka, India</p>
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">Customer Grievance &amp; Care:</strong><br />Email: <a href="mailto:care@bambaura.com" className="underline text-[#8c6027] dark:text-[#dfb983]">care@bambaura.com</a> | Desk: Concierge Email Desk (Mon–Sat 9AM–6PM IST)</p>
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">Storage Instructions:</strong><br />Store in a cool, dry place away from direct sunlight. Reseal pouch after each use with the built-in zip lock.</p>
                  <p><strong className="text-[#401010] dark:text-[#f7ebd9]">Allergen Statement:</strong><br />Naturally gluten-free, dairy-free, and vegan. Processed in a dedicated salt roasting facility.</p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: CUSTOMER REVIEWS (HONEST PRE-LAUNCH STATUS) */}
          {activeTab === 'reviews' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#faf5ee] dark:bg-[#1c0a0a] border border-[#e6d8c4] dark:border-[#381616]">
                <div>
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-amber-500" />
                    <span className="font-serif font-bold text-xl text-[#401010] dark:text-[#dfb983]">
                      Customer Reviews & Dining Feedback
                    </span>
                  </div>
                  <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-1.5 max-w-xl">
                    Our initial small-batch canisters are in preparation. Verified customer ratings, Michelin-style table impressions, and dining feedback will appear here post-commercial delivery.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setShowReviewModal(true)}
                  className="px-5 py-2.5 rounded-full bg-[#401010] dark:bg-[#dfb983] text-[#f7ebd9] dark:text-[#120505] text-xs font-bold uppercase tracking-wider shadow-md hover:opacity-90 transition-opacity whitespace-nowrap"
                >
                  [Demo] Test Review Submission
                </button>
              </div>

              {reviewsList.length === 0 ? (
                <div className="p-8 text-center rounded-2xl border border-dashed border-[#e6d8c4] dark:border-[#381616] space-y-2">
                  <p className="font-serif text-base font-bold text-[#401010] dark:text-[#f7ebd9]">
                    Pre-Launch Allocation in Progress
                  </p>
                  <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] max-w-md mx-auto">
                    No customer ratings have been published yet. You can use the demo submission form above to test how verified reviews appear in the storefront.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {reviewsList.map((rev) => (
                    <div key={rev.id} className="p-5 rounded-3xl bg-white dark:bg-[#180707] border border-[#e6d8c4] dark:border-[#381616] space-y-3 shadow-xs">
                      <div className="flex items-center justify-between">
                        <div className="flex text-amber-400">
                          {[...Array(rev.rating)].map((_, i) => (
                            <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                          ))}
                        </div>
                        <span className="text-xs text-amber-600 dark:text-amber-400 font-mono font-bold">
                          [DEMO PREVIEW]
                        </span>
                      </div>

                      <h5 className="font-serif font-bold text-sm text-[#401010] dark:text-[#f7ebd9]">
                        "{rev.title}"
                      </h5>

                      <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
                        {rev.comment}
                      </p>

                      <div className="flex items-center justify-between pt-2 border-t border-[#e6d8c4]/60 dark:border-[#381616] text-xs">
                        <span className="font-semibold text-[#401010] dark:text-[#dfb983]">
                          {rev.author} ({rev.location})
                        </span>
                        <span className="text-gray-500 font-mono">Demo Session Review</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* WRITE A REVIEW MODAL (ACCESSIBLE CLIENT DEMO MODAL) */}
      <AnimatePresence>
        {showReviewModal && (
          <div
            onClick={(e) => { if (e.target === e.currentTarget) setShowReviewModal(false) }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            role="dialog"
            aria-modal="true"
            aria-labelledby="demo-review-modal-title"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md p-6 rounded-3xl bg-[#faf5ee] dark:bg-[#180707] border border-[#b28346]/40 shadow-2xl space-y-4"
            >
              <div className="flex justify-between items-center border-b border-[#e6d8c4] dark:border-[#381616] pb-3">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/30 uppercase">
                    Client Demo
                  </span>
                  <h4 id="demo-review-modal-title" className="font-serif font-bold text-lg text-[#401010] dark:text-[#f7ebd9]">
                    Submit Test Review
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => setShowReviewModal(false)}
                  className="text-gray-500 hover:text-black dark:hover:text-white p-1 rounded-lg"
                  aria-label="Close demo review modal"
                >
                  ✕
                </button>
              </div>

              {/* DEMO NOTICE BANNER */}
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-[#8c6027] dark:text-[#dfb983] leading-relaxed">
                <strong>Demo Mode:</strong> This form demonstrates how reviews render. Submissions update the local session state only and are not stored in an external database.
              </div>

              <form onSubmit={handleReviewSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-[#401010] dark:text-[#dfb983] mb-1">
                    Your Name:
                  </label>
                  <input
                    type="text"
                    required
                    value={newReviewAuthor}
                    onChange={(e) => setNewReviewAuthor(e.target.value)}
                    placeholder="e.g. Priya R."
                    className="w-full p-2.5 rounded-xl border border-[#b28346]/40 bg-white dark:bg-[#120404] text-[#401010] dark:text-[#f7ebd9] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-[#401010] dark:text-[#dfb983] mb-1">
                    Rating (1 to 5 Stars):
                  </label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewReviewRating(star)}
                        className="p-1"
                        aria-label={`Rate ${star} stars`}
                      >
                        <Star className={`w-6 h-6 ${star <= newReviewRating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-[#401010] dark:text-[#dfb983] mb-1">
                    Your Review &amp; Experience:
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={newReviewComment}
                    onChange={(e) => setNewReviewComment(e.target.value)}
                    placeholder="Describe culinary usage, taste on eggs/meats/fruits, texture..."
                    className="w-full p-2.5 rounded-xl border border-[#b28346]/40 bg-white dark:bg-[#120404] text-[#401010] dark:text-[#f7ebd9] focus:outline-none"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowReviewModal(false)}
                    className="px-4 py-2 rounded-xl border border-gray-400 text-gray-700 dark:text-gray-300 font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 rounded-xl bg-[#401010] dark:bg-[#dfb983] text-[#f7ebd9] dark:text-[#120505] font-bold"
                  >
                    Record Demo Review
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MOBILE STICKY ADD-TO-CART BAR (BRIEF ITEM 16: "Add to cart") */}
      <div className="block lg:hidden fixed bottom-0 left-0 right-0 z-40 p-3 bg-white/95 dark:bg-[#160606]/95 border-t border-[#b28346]/30 backdrop-blur-md shadow-2xl">
        <div className="max-w-md mx-auto flex items-center justify-between gap-3">
          <div className="flex flex-col">
            <span className="text-xs uppercase font-mono tracking-wider text-gray-500 dark:text-gray-400">
              {currentGramVariant.label} • {currentGrindVariant.title}
            </span>
            <span className="font-serif font-bold text-lg text-[#401010] dark:text-[#dfb983] leading-tight">
              {formatPrice(effectivePriceUSD * quantity)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleAddToCart}
              className="px-3.5 py-2.5 rounded-xl border border-[#b28346] text-[#401010] dark:text-[#dfb983] text-xs font-bold uppercase tracking-wider active:scale-95 transition-all"
            >
              Add to cart
            </button>
            <button
              type="button"
              onClick={handleDirectBuyWithRazorpay}
              className="px-3.5 py-2.5 rounded-xl bg-[#401010] text-[#f7ebd9] dark:bg-[#dfb983] dark:text-[#120505] text-xs font-bold uppercase tracking-wider shadow-md active:scale-95 transition-all"
            >
              Buy Now
            </button>
          </div>
        </div>
      </div>

    </div>
  )
}
