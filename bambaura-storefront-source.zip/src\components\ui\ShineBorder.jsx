import React from 'react'

/**
 * Editorial Framed Card Component (formerly animated ShineBorder)
 * Restrained, high-contrast artisanal border without gimmicky rotating conic animations.
 */
export default function ShineBorder({
  children,
  className = ''
}) {
  return (
    <div className={`relative rounded-3xl border border-[#e6d8c4] dark:border-[#381616] bg-white dark:bg-[#180707] shadow-sm overflow-hidden ${className}`}>
      {children}
    </div>
  )
}

