import React, { useState, useEffect, useRef } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ShoppingBag, Sun, Moon, ChevronDown, Menu, X,
  LogOut, ShieldCheck, Flame, Sparkles, Check, Package,
  ChefHat, Phone, ArrowRight, Compass, BookOpen, HeartHandshake,
  Truck, Gift, Search, User, ExternalLink
} from 'lucide-react'
import { useStore, COUNTRIES_DATA } from '../context/StoreContext'
import NAV_DATA from '../data/navigation.json'

const SEARCH_INDEX = [
  { title: "Bambaura 9X Bamboo Roasted Salt (100g Signature Canister)", category: "Product", path: "/product?grams=100g", sub: "Flagship 9-cycle bamboo roasted salt" },
  { title: "Bambaura 9X Chef's Reserve (250g Canister + Gold Pouch)", category: "Product", path: "/product?grams=250g", sub: "Large canister with nitrogen-sealed foil pouch" },
  { title: "Fine Seasoning Granules", category: "Grind", path: "/product?grams=100g", sub: "Delicate tabletop pinch texture" },
  { title: "Coarse Finishing Crystals", category: "Grind", path: "/product?grams=250g", sub: "Crunch textural finishing crystals" },
  { title: "The 9 Roasting Cycles & Kiln Process", category: "Craft", path: "/process", sub: "21-day timeline from 800°C to 1,500°C" },
  { title: "Laboratory Toxicology & ICP-MS Testing", category: "Science", path: "/science", sub: "Heavy metals detection limits (LOD) & 0% microplastics" },
  { title: "Alkaline Mineral Profile (pH 9.8 - 10.2)", category: "Science", path: "/science", sub: "Natural mineral alkalinity and culinary softening" },
  { title: "Soft-Boiled Eggs with 9X Salt", category: "Recipe", path: "/recipes", sub: "Delicate smoky umami on morning eggs" },
  { title: "Grilled Ribeye & Paneer Tikka Finishing", category: "Recipe", path: "/recipes", sub: "High-heat sear savoury balance" },
  { title: "Chilled Watermelon & Dark Chocolate Pinch", category: "Recipe", path: "/recipes", sub: "Contrast sweet and smoky finishing" },
  { title: "Our Story & Mountain Sourcing", category: "Brand", path: "/about", sub: "The traditional craft of bamboo kiln firings" },
  { title: "Corporate & Wedding Gifting Concierge", category: "Gifting", path: "/contact?subject=Corporate+%26+Wedding+Gifting", sub: "Custom luxury canisters for celebrations" }
]

export default function Navbar() {
  const {
    theme,
    toggleTheme,
    country,
    setCountry,
    countryConfig,
    formatPrice,
    cartTotalUSD,
    productData,
    user,
    logout,
    setIsAuthModalOpen,
    cartItemsCount,
    setIsCartOpen
  } = useStore()

  const location = useLocation()
  const navigate = useNavigate()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [countryDropdownOpen, setCountryDropdownOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  const countryRef = useRef(null)
  const searchInputRef = useRef(null)

  // Focus search input when modal opens
  useEffect(() => {
    if (isSearchOpen && searchInputRef.current) {
      setTimeout(() => searchInputRef.current?.focus(), 50)
    }
  }, [isSearchOpen])

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event) {
      if (countryRef.current && !countryRef.current.contains(event.target)) {
        setCountryDropdownOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // Close mobile menu and search on route change
  useEffect(() => {
    setMobileMenuOpen(false)
    setIsSearchOpen(false)
  }, [location.pathname])

  // Keyboard escape listener for search
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && isSearchOpen) {
        setIsSearchOpen(false)
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setIsSearchOpen(prev => !prev)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [isSearchOpen])

  const filteredSearchResults = searchQuery.trim()
    ? SEARCH_INDEX.filter(item =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.sub.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : SEARCH_INDEX.slice(0, 5)

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/'
    return location.pathname.startsWith(path)
  }

  // Exact 6 links from the reference design mockup
  const navigationLinks = [
    { label: 'Shop', path: '/product' },
    { label: 'Our Story', path: '/about' },
    { label: 'Why 9X', path: '/process' },
    { label: 'Recipes', path: '/recipes' },
    { label: 'Lab Results', path: '/science' },
    { label: 'Gifting', path: '/contact?subject=Corporate+%26+Wedding+Gifting' }
  ]

  return (
    <>
      {/* 1. TOP ANNOUNCEMENT BAR (MATCHES MOCKUP EXACTLY) */}
      <div className="bg-[#401010] dark:bg-[#1a0505] text-[#faf5ee] text-xs py-2 px-4 sm:px-8 border-b border-[#5c1c1c] transition-colors">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs tracking-wide">
          
          {/* Left Free Shipping Promise */}
          <div className="flex items-center gap-2 font-medium">
            <span>Free shipping over $50 (US) | Free delivery over £40 (UK)</span>
            <span className="hidden md:inline opacity-70">•</span>
            <span className="hidden md:inline opacity-90">Nine Roasting Cycles Inside Bamboo</span>
          </div>

          {/* Right Region & Currency Dropdown */}
          <div className="relative" ref={countryRef}>
            <button
              type="button"
              onClick={() => setCountryDropdownOpen(!countryDropdownOpen)}
              className="flex items-center gap-1.5 font-medium hover:text-[#dfb983] transition-colors cursor-pointer py-0.5"
              aria-label="Select Country and Currency"
            >
              <span>{countryConfig.code === 'USD' ? 'US (USD)' : countryConfig.code === 'GBP' ? 'UK (GBP)' : countryConfig.code === 'INR' ? 'IN (INR)' : `${countryConfig.code}`}</span>
              <ChevronDown className={`w-3 h-3 text-[#dfb983] transition-transform duration-200 ${countryDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            <AnimatePresence>
              {countryDropdownOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 6, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 6, scale: 0.96 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 mt-2 w-56 rounded-2xl bg-[#2a0808] border border-[#b28346]/40 shadow-2xl p-2 z-50 text-xs text-[#faf5ee]"
                >
                  <div className="px-3 py-1 font-bold text-xs uppercase tracking-wider text-[#dfb983] border-b border-[#401010] pb-1.5 mb-1">
                    Select Region & Currency
                  </div>
                  <div className="space-y-1">
                    {Object.entries(COUNTRIES_DATA).map(([key, data]) => {
                      const isCurrent = country === key
                      return (
                        <button
                          key={key}
                          type="button"
                          onClick={() => {
                            setCountry(key)
                            setCountryDropdownOpen(false)
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-left transition-colors ${
                            isCurrent
                              ? 'bg-[#b28346] text-[#1e0505] font-bold'
                              : 'text-amber-100 hover:bg-[#401010]'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span>{data.flag}</span>
                            <span>{data.name}</span>
                          </div>
                          <span className="font-mono font-bold">{data.code}</span>
                        </button>
                      )
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>
      </div>

      {/* 2. MAIN NAVBAR (MATCHES MOCKUP EXACTLY) */}
      <header className="sticky top-0 z-40 bg-[#faf6f0] dark:bg-[#120505] border-b border-[#e8decb] dark:border-[#381616] transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 h-18 sm:h-20 flex items-center justify-between">
          
          {/* MOBILE HAMBURGER BUTTON (LEFT ON MOBILE) */}
          <div className="flex lg:hidden items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 -ml-2 text-[#401010] dark:text-[#f7ebd9] hover:text-[#8c6027] transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* BRAND LOGO: EXACT MATCH TO MOCKUP (GOLD EMBLEM + SERIF BAMBAURA) */}
          <Link to="/" className="flex items-center gap-2.5 sm:gap-3 group shrink-0">
            <img
              src="/images/extracted/b_mark_full.png"
              alt="Bambaura emblem"
              className="w-7 h-7 sm:w-8 sm:h-8 object-contain filter drop-shadow-xs transition-transform group-hover:scale-105"
            />
            <span className="font-serif text-2xl sm:text-3xl font-semibold tracking-tight text-[#381214] dark:text-[#fdfbf7] group-hover:text-[#8c6027] dark:group-hover:text-[#dfb983] transition-colors">
              Bambaura
            </span>
          </Link>

          {/* DESKTOP NAV LINKS (EXACT 6 LINKS IN CLEAN SANS-SERIF) */}
          <nav className="hidden lg:flex items-center gap-7 xl:gap-9">
            {navigationLinks.map((item) => {
              const active = isActive(item.path)
              return (
                <Link
                  key={item.label}
                  to={item.path}
                  className={`text-[13px] tracking-[0.06em] font-medium transition-colors py-1 relative ${
                    active
                      ? 'text-[#401010] dark:text-[#dfb983] font-bold'
                      : 'text-[#2c1714] dark:text-[#e4d4cb] hover:text-[#8c6027] dark:hover:text-[#dfb983]'
                  }`}
                >
                  <span>{item.label}</span>
                  {active && (
                    <motion.div
                      layoutId="cleanNavUnderline"
                      className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#401010] dark:bg-[#dfb983]"
                      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                    />
                  )}
                </Link>
              )
            })}
          </nav>

          {/* RIGHT ACTION ICONS: SEARCH, USER, CART (MATCHES MOCKUP EXACTLY) */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            
            {/* SEARCH ICON BUTTON */}
            <button
              type="button"
              onClick={() => setIsSearchOpen(true)}
              className="p-2 text-[#381214] dark:text-[#f7ebd9] hover:text-[#8c6027] transition-colors rounded-full hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
              title="Search products, recipes, lab tests (Ctrl+K)"
              aria-label="Search"
            >
              <Search className="w-5 h-5 stroke-[1.8]" />
            </button>

            {/* USER / PATRON ACCOUNT BUTTON */}
            <button
              type="button"
              onClick={() => {
                if (user) {
                  logout()
                } else {
                  setIsAuthModalOpen(true)
                }
              }}
              className="p-2 text-[#381214] dark:text-[#f7ebd9] hover:text-[#8c6027] transition-colors rounded-full hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
              title={user ? `Signed in as ${user.name} (Click to sign out)` : "Sign in / Patron Account"}
              aria-label="User Account"
            >
              <User className="w-5 h-5 stroke-[1.8]" />
            </button>

            {/* SHOPPING CART ICON WITH CIRCULAR BURGUNDY BADGE */}
            <button
              type="button"
              onClick={() => setIsCartOpen(true)}
              className="p-2 text-[#381214] dark:text-[#f7ebd9] hover:text-[#8c6027] transition-colors relative rounded-full hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
              title="Open Shopping Bag"
              aria-label="Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5 stroke-[1.8]" />
              {/* EXACT BADGE STYLE FROM MOCKUP: MAROON CIRCLE WITH WHITE COUNT */}
              <span className="absolute top-1 right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#401010] text-[#faf5ee] text-[11px] font-mono font-bold flex items-center justify-center leading-none shadow-xs">
                {cartItemsCount}
              </span>
            </button>

            {/* LIGHT/DARK THEME TOGGLE (DISCREET & CLEAN) */}
            <button
              type="button"
              onClick={toggleTheme}
              className="hidden sm:flex p-2 text-[#381214] dark:text-[#f7ebd9] hover:text-[#8c6027] transition-colors rounded-full hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
              title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} mode`}
              aria-label="Toggle Theme"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-300" />
              ) : (
                <Moon className="w-4 h-4 text-[#401010]" />
              )}
            </button>

          </div>

        </div>
      </header>

      {/* 3. INLINE SEARCH MODAL (CLEAN LUXURY EXPERIENCE) */}
      <AnimatePresence>
        {isSearchOpen && (
          <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, y: -20, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.98 }}
              transition={{ duration: 0.18 }}
              className="w-full max-w-2xl bg-[#faf6f0] dark:bg-[#1a0808] rounded-3xl border border-[#b28346]/40 shadow-2xl overflow-hidden p-6 text-[#2c1714] dark:text-[#fdfbf7]"
            >
              <div className="flex items-center justify-between pb-4 border-b border-[#e8decb] dark:border-[#381616]">
                <div className="flex items-center gap-3 flex-1">
                  <Search className="w-5 h-5 text-[#8c6027] shrink-0" />
                  <input
                    ref={searchInputRef}
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search salts, recipes, lab results, craft..."
                    className="w-full bg-transparent text-base outline-none text-[#2c1714] dark:text-[#fdfbf7] placeholder:text-[#9c8378]"
                  />
                </div>
                <button
                  onClick={() => setIsSearchOpen(false)}
                  className="p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/5 text-gray-500 hover:text-black dark:hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 max-h-96 overflow-y-auto space-y-2">
                <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#8c6027] px-2">
                  {searchQuery.trim() ? "Search Results" : "Quick Suggestions"}
                </div>
                {filteredSearchResults.length === 0 ? (
                  <p className="p-4 text-xs text-gray-500 text-center">No results found for "{searchQuery}". Try "100g", "recipes", or "COA".</p>
                ) : (
                  filteredSearchResults.map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        navigate(item.path)
                        setIsSearchOpen(false)
                      }}
                      className="w-full p-3 rounded-2xl hover:bg-white dark:hover:bg-[#250d0d] border border-transparent hover:border-[#e8decb] dark:hover:border-[#381616] text-left transition-all flex items-center justify-between group"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-serif font-bold text-sm text-[#401010] dark:text-[#dfb983] group-hover:text-[#8c6027]">
                            {item.title}
                          </span>
                          <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-[#f0e7d8] dark:bg-[#381616] text-[#8c6027] dark:text-[#dfb983]">
                            {item.category}
                          </span>
                        </div>
                        <p className="text-xs text-[#6b534b] dark:text-[#c2ada4] mt-0.5">
                          {item.sub}
                        </p>
                      </div>
                      <ArrowRight className="w-4 h-4 text-[#8c6027] opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. MOBILE SLIDE-OUT MENU */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.22 }}
            className="lg:hidden bg-[#faf6f0] dark:bg-[#120505] border-b border-[#e8decb] dark:border-[#381616] px-6 py-6 overflow-hidden shadow-xl"
          >
            <nav className="flex flex-col space-y-3">
              {navigationLinks.map((item) => (
                <Link
                  key={item.label}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className="font-serif text-lg font-semibold text-[#381214] dark:text-[#fdfbf7] hover:text-[#8c6027] py-2 border-b border-[#e8decb]/60 dark:border-[#381616] flex items-center justify-between"
                >
                  <span>{item.label}</span>
                  <ArrowRight className="w-4 h-4 text-[#8c6027]" />
                </Link>
              ))}
            </nav>

            <div className="pt-6 mt-4 border-t border-[#e8decb] dark:border-[#381616] flex items-center justify-between text-xs text-[#6b534b] dark:text-[#c2ada4]">
              <span>Free Delivery on qualifying orders</span>
              <button
                type="button"
                onClick={toggleTheme}
                className="flex items-center gap-1.5 font-semibold text-[#401010] dark:text-[#dfb983]"
              >
                {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4" />}
                <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
