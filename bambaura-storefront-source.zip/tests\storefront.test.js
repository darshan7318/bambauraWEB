import { describe, it } from 'node:test'
import assert from 'node:assert'
import fs from 'node:fs'
import path from 'node:path'

const ROOT = process.cwd()

describe('1. Storefront Claims & Regulatory Integrity', () => {
  it('Product data should reflect honest pre-launch status without fake ratings', () => {
    const raw = fs.readFileSync(path.join(ROOT, 'src/data/product.json'), 'utf8')
    const product = JSON.parse(raw)

    assert.strictEqual(product.preLaunch, true, 'Product should be marked preLaunch: true')
    assert.strictEqual(product.rating, null, 'Rating should be null or unasserted')
    assert.strictEqual(product.reviewsCount, 0, 'reviewsCount must be 0 prior to verified launch sales')
    assert.ok(product.gramVariants && product.gramVariants.length >= 4, 'Must offer all 4 pack sizes')
    
    product.gramVariants.forEach(variant => {
      assert.ok(variant.priceUSD > 0, `Price for ${variant.grams} must be > 0`)
      assert.ok(variant.amazonUSD >= variant.priceUSD, `Direct price should offer discount over Amazon MRP`)
    })
  })

  it('Science data should use neutral protocol benchmarks without fabricated credentials', () => {
    const raw = fs.readFileSync(path.join(ROOT, 'src/data/science.json'), 'utf8')
    const science = JSON.parse(raw)

    // Check that batches do not use invented analyst credentials
    science.batches.forEach(batch => {
      assert.doesNotMatch(batch.leadAnalyst, /Dr\. V\. Ramanathan/i, 'Must not publish fictional analyst names')
      assert.doesNotMatch(batch.labAccreditationNo, /TC-8492/i, 'Must not publish fabricated NABL certificate IDs')
      assert.ok(batch.testedParameters.length >= 3, 'Must detail toxicology, combustion, and purity parameters')
      
      // Ensure all parameters report genuine LOD (Limit of Detection) rather than naive 0.000
      batch.testedParameters.forEach(param => {
        assert.ok(
          param.result.includes('Below detection limit') || param.result.includes('0') || param.result.includes('None'),
          `Parameter ${param.parameter} should report scientific detection limits`
        )
      })
    })

    // Check certifications array
    science.certifications.forEach(cert => {
      assert.doesNotMatch(cert.desc, /10024011000189/i, 'Must not claim fabricated FSSAI license numbers')
      assert.doesNotMatch(cert.desc, /19482018492/i, 'Must not claim fabricated FDA registration numbers')
    })
  })

  it('Contact data should use verified concierge email and no placeholder phone numbers', () => {
    const raw = fs.readFileSync(path.join(ROOT, 'src/data/contact.json'), 'utf8')
    const contact = JSON.parse(raw)

    assert.strictEqual(contact.channels.email.address, 'care@bambaura.com')
    assert.doesNotMatch(contact.channels.whatsapp.subtext, /98450\s*12345/, 'Must not publish placeholder mobile numbers')
  })
})

describe('2. Financial Math & Multi-Currency Engine', () => {
  const COUNTRIES = {
    IN: { code: 'INR', symbol: '₹', rate: 83, freeShip: 999 },
    US: { code: 'USD', symbol: '$', rate: 1, freeShip: 50 },
    GB: { code: 'GBP', symbol: '£', rate: 0.79, freeShip: 40 },
    EU: { code: 'EUR', symbol: '€', rate: 0.92, freeShip: 45 },
    AE: { code: 'AED', symbol: 'AED ', rate: 3.67, freeShip: 180 }
  }

  const formatPrice = (priceUSD, countryCode = 'IN') => {
    const config = COUNTRIES[countryCode]
    const converted = priceUSD * config.rate
    if (config.code === 'INR') {
      const rounded = Math.round(converted / 50) * 50
      return `${config.symbol}${rounded.toLocaleString('en-IN')}`
    }
    return `${config.symbol}${Math.round(converted)}`
  }

  it('Formats Indian Rupee prices cleanly with INR grouping', () => {
    const p100g = formatPrice(24, 'IN')
    // 24 * 83 = 1992 -> rounded to nearest 50 = 2000
    assert.strictEqual(p100g, '₹2,000')

    const p500g = formatPrice(68, 'IN')
    // 68 * 83 = 5644 -> rounded to nearest 50 = 5650
    assert.strictEqual(p500g, '₹5,650')
  })

  it('Calculates 15% Subscribe & Save discount accurately without float errors', () => {
    const basePrices = [15, 24, 42, 68]
    basePrices.forEach(base => {
      const discounted = Math.round(base * 0.85)
      assert.ok(discounted < base, 'Discounted price must be less than base')
      assert.strictEqual(discounted, Math.round(base * 0.85), 'Must be clean integer')
    })
  })

  it('Evaluates free shipping eligibility accurately across currencies', () => {
    Object.entries(COUNTRIES).forEach(([code, config]) => {
      const qualifyAmount = config.freeShip
      assert.ok(qualifyAmount > 0, `Free shipping threshold for ${code} must be > 0`)
    })
  })
})

describe('3. Client Demo Isolation & Safety Guarantees', () => {
  it('RazorpayModal must contain explicit demo warning banners and isolation', () => {
    const code = fs.readFileSync(path.join(ROOT, 'src/components/RazorpayModal.jsx'), 'utf8')
    assert.ok(code.includes('Demo Preview Receipt — Not a Real Charge'), 'Must display demo receipt warning banner')
    assert.ok(code.includes('role="dialog"'), 'Must have accessible dialog role')
    assert.ok(code.includes('aria-modal="true"'), 'Must have aria-modal attribute')
    assert.doesNotMatch(code, /Himalayan/i, 'Must never position Bambaura as Himalayan rock salt')
  })

  it('GoogleSSOModal must isolate demo authentication and support Escape listener', () => {
    const code = fs.readFileSync(path.join(ROOT, 'src/components/GoogleSSOModal.jsx'), 'utf8')
    assert.ok(code.includes('role="dialog"'), 'Must have accessible dialog role')
    assert.ok(code.includes('Escape'), 'Must support keyboard dismissal')
    assert.doesNotMatch(code, /Lord Julian Thorne/i, 'Must not use feudal persona placeholders')
  })

  it('Product page must present honest pre-launch reviews state with demo submission tag', () => {
    const code = fs.readFileSync(path.join(ROOT, 'src/pages/Product.jsx'), 'utf8')
    assert.ok(code.includes('INITIAL_REVIEWS = []'), 'INITIAL_REVIEWS must be empty array')
    assert.ok(code.includes('Demo Review Submission'), 'Submissions must be tagged as demo reviews')
    assert.ok(code.includes('role="dialog"'), 'Review modal must have accessible dialog role')
  })
})

describe('4. Routing Architecture & 404 Recovery', () => {
  it('App.jsx must wire all required routes and a dedicated 404 catch-all', () => {
    const appCode = fs.readFileSync(path.join(ROOT, 'src/App.jsx'), 'utf8')
    assert.ok(appCode.includes('path="*" element={<NotFound />}'), 'Catch-all wildcard route must render NotFound component')
    assert.ok(appCode.includes('path="/" element={<Home />}'), 'Must render Home route')
    assert.ok(appCode.includes('path="/product" element={<Product />}'), 'Must render Product route')
    assert.ok(appCode.includes('path="/process" element={<Process />}'), 'Must render Process route')
    assert.ok(appCode.includes('path="/science" element={<Science />}'), 'Must render Science route')
    assert.ok(appCode.includes('path="/recipes" element={<Recipes />}'), 'Must render Recipes route')
    assert.ok(appCode.includes('path="/about" element={<About />}'), 'Must render About route')
    assert.ok(appCode.includes('path="/contact" element={<Contact />}'), 'Must render Contact route')
    assert.ok(appCode.includes('path="/affiliate" element={<Affiliate />}'), 'Must render Affiliate route')
    assert.ok(appCode.includes('path="/admin" element={<Admin />}'), 'Must render Admin route')
  })

  it('NotFound.jsx must provide home return action and brand styling', () => {
    const nfCode = fs.readFileSync(path.join(ROOT, 'src/pages/NotFound.jsx'), 'utf8')
    assert.ok(nfCode.includes('Return to Home'), 'Must have recovery link')
    assert.ok(nfCode.includes('404'), 'Must communicate 404 error clearly')
  })
})

describe('5. Anti-AI-Slop & Design System Conformance', () => {
  it('Pages must adhere to the 12px typography floor without sub-12px microtext', () => {
    const pagesDir = path.join(ROOT, 'src/pages')
    const files = fs.readdirSync(pagesDir).filter(f => f.endsWith('.jsx'))
    files.forEach(f => {
      const content = fs.readFileSync(path.join(pagesDir, f), 'utf8')
      assert.doesNotMatch(
        content,
        /text-\[(?:[0-9]|1[01])px\]/,
        `Page ${f} must not contain sub-12px micro-text (found violation)`
      )
    })
  })

  it('Pages must not render generic rotating ShineBorder or repetitive SpotlightCard', () => {
    const pagesDir = path.join(ROOT, 'src/pages')
    const files = fs.readdirSync(pagesDir).filter(f => f.endsWith('.jsx'))
    files.forEach(f => {
      const content = fs.readFileSync(path.join(pagesDir, f), 'utf8')
      assert.doesNotMatch(
        content,
        /<ShineBorder|<SpotlightCard/,
        `Page ${f} must not render rotating ShineBorder or SpotlightCard`
      )
    })
  })

  it('BenefitsSection must use evidence-safe mineral descriptions without 60+ minerals claims', () => {
    const code = fs.readFileSync(path.join(ROOT, 'src/components/BenefitsSection.jsx'), 'utf8')
    assert.doesNotMatch(code, /60\+\s*Essential Trace Minerals/i, 'Must not claim 60+ trace minerals')
    assert.ok(code.includes('Natural Ocean & Bamboo Trace Minerals'), 'Must use evidence-safe trace minerals description')
  })
})
