import React from 'react'
import { Link } from 'react-router-dom'
import { Compass, ArrowRight, Home, ShoppingBag, Mail } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 sm:px-6 py-16">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="w-20 h-20 rounded-3xl bg-[#faf5ee] dark:bg-[#1f0b0b] border border-[#b28346]/40 text-[#b28346] dark:text-[#dfb983] flex items-center justify-center mx-auto shadow-lg">
          <Compass className="w-10 h-10 animate-spin-slow" />
        </div>

        <div className="space-y-2">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#8c6027] dark:text-[#dfb983]">
            Error 404 • Navigation Reference
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#401010] dark:text-[#f7ebd9]">
            Page Not Found
          </h1>
          <p className="text-sm text-[#6b534b] dark:text-[#c2ada4] leading-relaxed">
            The page you requested does not exist or has been relocated. Please use the navigation links below to return to the Bambaura collection.
          </p>
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            to="/"
            className="w-full sm:w-auto px-6 py-3.5 rounded-full bg-[#401010] dark:bg-[#dfb983] text-[#f7ebd9] dark:text-[#120505] font-semibold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md hover:opacity-95 transition-opacity"
          >
            <Home className="w-4 h-4" />
            <span>Return to Home</span>
          </Link>

          <Link
            to="/product"
            className="w-full sm:w-auto px-6 py-3.5 rounded-full border border-[#b28346] text-[#401010] dark:text-[#dfb983] font-semibold text-xs uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>View Salt Canisters</span>
          </Link>
        </div>

        <div className="pt-4 border-t border-[#e6d8c4] dark:border-[#381616] text-xs text-[#6b534b] dark:text-[#c2ada4]">
          <span>Need assistance? </span>
          <Link to="/contact" className="underline font-bold text-[#401010] dark:text-[#dfb983]">
            Contact our Concierge
          </Link>
        </div>
      </div>
    </div>
  )
}

